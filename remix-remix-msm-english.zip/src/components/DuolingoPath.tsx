import { FC, useState } from 'react';
import { 
  Star, Trophy, Crown, Gift, Headphones, Check, Lock, Play, 
  Heart, Sparkles, AlertCircle, X, ArrowRight, Volume2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PathNode, QuizQuestion, Lesson } from '../types';
import { LEARNING_PATH_NODES, QUICK_QUIZ_QUESTIONS, INITIAL_LESSONS } from '../data/mockData';

interface DuolingoPathProps {
  nodes: PathNode[];
  hearts: number;
  gems: number;
  onUpdateHearts: (updater: (prev: number) => number) => void;
  onAddGems: (amount: number) => void;
  onAddXp: (amount: number) => void;
  onNodeComplete: (nodeId: string) => void;
}

export const DuolingoPath: FC<DuolingoPathProps> = ({
  nodes,
  hearts,
  gems,
  onUpdateHearts,
  onAddGems,
  onAddXp,
  onNodeComplete,
}) => {
  const [selectedNode, setSelectedNode] = useState<PathNode | null>(null);
  const [activeQuiz, setActiveQuiz] = useState<QuizQuestion | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [quizResult, setQuizResult] = useState<'correct' | 'wrong' | null>(null);
  const [chestOpened, setChestOpened] = useState<boolean>(false);

  // Group nodes by units
  const unit1Nodes = nodes.filter((n) => n.unitNumber === 1);
  const unit2Nodes = nodes.filter((n) => n.unitNumber === 2);
  const unit3Nodes = nodes.filter((n) => n.unitNumber === 3);
  const unit4Nodes = nodes.filter((n) => n.unitNumber === 4);

  const handleOpenNode = (node: PathNode) => {
    if (node.status === 'locked') return;
    setSelectedNode(node);
    setChestOpened(false);
    setQuizResult(null);
    setSelectedOption(null);

    if (node.type === 'quiz' || node.type === 'boss') {
      const q = QUICK_QUIZ_QUESTIONS[Math.floor(Math.random() * QUICK_QUIZ_QUESTIONS.length)];
      setActiveQuiz(q);
    } else {
      setActiveQuiz(null);
    }
  };

  const handleOpenChest = () => {
    if (chestOpened) return;
    setChestOpened(true);
    onAddGems(35);
    onAddXp(20);
    if (selectedNode) {
      onNodeComplete(selectedNode.id);
    }
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 }
    });
  };

  const handleCheckQuizAnswer = () => {
    if (!activeQuiz || !selectedOption) return;

    if (selectedOption === activeQuiz.correctAnswer) {
      setQuizResult('correct');
      onAddXp(selectedNode ? selectedNode.xpReward : 30);
      onAddGems(10);
      if (selectedNode) {
        onNodeComplete(selectedNode.id);
      }
      confetti({
        particleCount: 65,
        spread: 80,
        origin: { y: 0.7 }
      });
    } else {
      setQuizResult('wrong');
      onUpdateHearts((prev) => Math.max(0, prev - 1));
    }
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US';
      u.rate = 0.85;
      window.speechSynthesis.speak(u);
    }
  };

  const getNodeColorClasses = (node: PathNode) => {
    if (node.status === 'locked') {
      return 'bg-emerald-950/70 border-emerald-900 text-emerald-700 cursor-not-allowed opacity-60';
    }

    switch (node.colorType) {
      case 'red':
        return 'duo-btn-red text-white shadow-lg shadow-red-950/40';
      case 'brown':
        return 'duo-btn-brown text-amber-100 shadow-lg shadow-amber-950/40';
      case 'gold':
        return 'duo-btn-yellow text-amber-950 shadow-lg shadow-yellow-950/40';
      case 'blue':
        return 'duo-btn-blue text-white shadow-lg shadow-sky-950/40';
      case 'green':
      default:
        return 'duo-btn-green text-white shadow-lg shadow-emerald-950/40';
    }
  };

  // Render a wavy Duolingo path with alternating horizontal offsets
  const renderPathNodes = (nodeList: PathNode[]) => {
    return (
      <div className="flex flex-col items-center gap-6 my-4">
        {nodeList.map((node, index) => {
          // calculate an alternating horizontal offset (-40px, 0px, 40px, 0px)
          const offsets = ['translate-x-0', '-translate-x-8 sm:-translate-x-12', 'translate-x-0', 'translate-x-8 sm:translate-x-12'];
          const offsetClass = offsets[index % offsets.length];

          const isCurrentActive = node.status === 'active';

          return (
            <div key={node.id} className={`relative flex flex-col items-center ${offsetClass}`}>
              {/* Tooltip for current active node */}
              {isCurrentActive && (
                <div className="absolute -top-9 z-10 animate-bounce">
                  <div className="bg-amber-400 text-amber-950 font-black text-xs px-3 py-1 rounded-xl shadow-md border-b-2 border-amber-600 flex items-center gap-1 whitespace-nowrap">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>ابدأ الآن!</span>
                  </div>
                </div>
              )}

              {/* Stepping stone button */}
              <button
                onClick={() => handleOpenNode(node)}
                disabled={node.status === 'locked'}
                className={`w-20 h-20 rounded-full flex flex-col items-center justify-center relative cursor-pointer font-bold ${getNodeColorClasses(node)}`}
                title={node.titleAr}
              >
                {node.type === 'chest' ? (
                  <Gift className="w-8 h-8" />
                ) : node.type === 'boss' ? (
                  <Crown className="w-9 h-9 animate-pulse" />
                ) : node.type === 'audio' ? (
                  <Headphones className="w-8 h-8" />
                ) : node.type === 'quiz' ? (
                  <Trophy className="w-8 h-8" />
                ) : (
                  <Star className="w-8 h-8" />
                )}

                {/* Stars ribbon for completed nodes */}
                {node.status === 'completed' && (
                  <div className="absolute -bottom-2 flex items-center justify-center gap-0.5 bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full text-[10px] font-black border border-amber-600 shadow">
                    <Star className="w-3 h-3 fill-amber-950" />
                    <span>{node.stars || 3}</span>
                  </div>
                )}

                {/* Lock icon */}
                {node.status === 'locked' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full">
                    <Lock className="w-6 h-6 text-emerald-800" />
                  </div>
                )}
              </button>

              {/* Node Title */}
              <div className="mt-2 text-center max-w-[130px]">
                <p className="text-xs font-bold text-emerald-100 leading-tight">{node.titleAr}</p>
                <p className="text-[10px] text-emerald-400/80 font-en font-medium">{node.titleEn}</p>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="w-full">
      {/* Unit 1 Header: Green Palette */}
      <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-green-800 rounded-3xl p-5 border-b-4 border-emerald-950 shadow-xl mb-4 text-white">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-black tracking-wider uppercase bg-emerald-900/80 text-emerald-200 px-2.5 py-1 rounded-lg">
              الوحدة 1 (اللون الأخضر)
            </span>
            <h3 className="text-lg sm:text-xl font-black mt-1">أساسيات المحادثة والتحيات اليومية</h3>
            <p className="text-xs text-emerald-100/90 mt-0.5">خطوات البداية الذكية لكسر حاجز الخوف وتثبيت المضارع البسيط</p>
          </div>
          <div className="flex items-center gap-2 bg-emerald-900/60 px-3 py-1.5 rounded-2xl border border-emerald-600/40 text-xs font-bold">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>المستوى التأسيسي</span>
          </div>
        </div>
      </div>

      {/* Unit 1 Nodes Path */}
      {renderPathNodes(unit1Nodes)}

      {/* Unit 2 Header: Brown & Gold Palette */}
      <div className="bg-gradient-to-r from-amber-900 via-amber-800 to-yellow-900 rounded-3xl p-5 border-b-4 border-amber-950 shadow-xl my-6 text-amber-50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-black tracking-wider uppercase bg-amber-950/80 text-amber-300 px-2.5 py-1 rounded-lg">
              الوحدة 2 (اللون البني والذهبي)
            </span>
            <h3 className="text-lg sm:text-xl font-black mt-1">الروتين اليومي والوظائف والطعام</h3>
            <p className="text-xs text-amber-200/90 mt-0.5">تطوير الجمل الطويلة والتعامل في المطاعم ومحطات السفر</p>
          </div>
          <div className="flex items-center gap-2 bg-amber-950/60 px-3 py-1.5 rounded-2xl border border-amber-700/40 text-xs font-bold text-amber-300">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>تحدي منتصف المسار</span>
          </div>
        </div>
      </div>

      {/* Unit 2 Nodes Path */}
      {renderPathNodes(unit2Nodes)}

      {/* Unit 3 Header: Dark Red / Crimson Palette */}
      <div className="bg-gradient-to-r from-red-900 via-red-800 to-rose-950 rounded-3xl p-5 border-b-4 border-red-950 shadow-xl my-6 text-red-50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-black tracking-wider uppercase bg-red-950/80 text-red-300 px-2.5 py-1 rounded-lg">
              الوحدة 3 (اللون الأحمر الداكن)
            </span>
            <h3 className="text-lg sm:text-xl font-black mt-1">سرد الماضي والمستقبل والمكالمات</h3>
            <p className="text-xs text-red-200/90 mt-0.5">إتقان الحديث عن التجارب السابقة ومشاريعك القادمة بدقة تامة</p>
          </div>
          <div className="flex items-center gap-2 bg-red-950/60 px-3 py-1.5 rounded-2xl border border-red-700/40 text-xs font-bold text-rose-300">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>سيد السرد والمحادثة</span>
          </div>
        </div>
      </div>

      {/* Unit 3 Nodes Path */}
      {renderPathNodes(unit3Nodes)}

      {/* Unit 4 Header: Grand Graduation Gold */}
      <div className="bg-gradient-to-r from-yellow-700 via-amber-600 to-yellow-800 rounded-3xl p-5 border-b-4 border-amber-950 shadow-xl my-6 text-amber-950">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-black tracking-wider uppercase bg-amber-900 text-amber-200 px-2.5 py-1 rounded-lg">
              الوحدة 4 (التاج الذهبي)
            </span>
            <h3 className="text-lg sm:text-xl font-black mt-1 text-white">الطلاقة المتقدمة ومقابلات العمل والتخرج</h3>
            <p className="text-xs text-amber-100 mt-0.5">تحديات متقدمة لاجتياز مقابلات العمل ونيل شهادة إتقان MSM ENGLISH</p>
          </div>
          <div className="flex items-center gap-2 bg-amber-900/80 px-3 py-1.5 rounded-2xl border border-amber-500 text-xs font-bold text-amber-200">
            <Crown className="w-5 h-5 text-amber-300 fill-amber-400" />
            <span>الشهادة النهائية</span>
          </div>
        </div>
      </div>

      {/* Unit 4 Nodes Path */}
      {renderPathNodes(unit4Nodes)}

      {/* Interactive Node Modal (Lesson / Quiz / Chest) */}
      {selectedNode && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b2314] border-2 border-emerald-600 rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl text-right">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-emerald-900 pb-3 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600/30 flex items-center justify-center text-emerald-400">
                  {selectedNode.type === 'chest' ? <Gift className="w-5 h-5" /> : <Star className="w-5 h-5" />}
                </div>
                <div>
                  <h4 className="text-white font-black text-base">{selectedNode.titleAr}</h4>
                  <p className="text-xs text-emerald-400 font-en">{selectedNode.titleEn}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedNode(null)}
                className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-300 hover:text-white flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chest Content */}
            {selectedNode.type === 'chest' ? (
              <div className="text-center py-6">
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-tr from-amber-700 to-amber-500 rounded-3xl flex items-center justify-center text-amber-100 shadow-xl border-4 border-amber-950 animate-bounce">
                  <Gift className="w-14 h-14" />
                </div>
                <h3 className="text-white font-black text-xl mb-1">صندوق المكافآت الذهبية!</h3>
                <p className="text-xs text-emerald-300 mb-6">افتح الصندوق لتحصل على المجوهرات ونقاط الـ XP المجانية لتشجيعك في مسارك</p>

                {chestOpened ? (
                  <div className="bg-emerald-950/80 border border-emerald-700 rounded-2xl p-4 text-center">
                    <span className="text-sm font-black text-amber-400 block mb-1">مبروك! حصلت على:</span>
                    <div className="flex items-center justify-center gap-4 text-xs font-bold text-white">
                      <span className="flex items-center gap-1 text-cyan-300">💎 +35 جوهرة</span>
                      <span className="flex items-center gap-1 text-amber-300">⭐ +20 XP</span>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={handleOpenChest}
                    className="w-full duo-btn-yellow text-amber-950 font-black text-sm py-3.5 rounded-2xl shadow-lg cursor-pointer"
                  >
                    افتح الكنز الآن
                  </button>
                )}
              </div>
            ) : activeQuiz ? (
              /* Quiz Modal Content */
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-emerald-300 bg-emerald-950/80 p-2.5 rounded-xl border border-emerald-900">
                  <div className="flex items-center gap-1.5 text-rose-400 font-bold">
                    <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                    <span>القلوب المتبقية: {hearts}</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-400 font-bold">
                    <Trophy className="w-4 h-4" />
                    <span>الجائزة: +{selectedNode.xpReward} XP</span>
                  </div>
                </div>

                <div className="bg-emerald-950/50 p-4 rounded-2xl border border-emerald-800 text-center">
                  <span className="text-xs font-bold text-emerald-400 block mb-1">السؤال التفاعلي:</span>
                  <p className="text-white font-black text-sm sm:text-base mb-2">{activeQuiz.promptAr}</p>
                  {activeQuiz.questionEn && (
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-xs font-en text-emerald-200 font-semibold">{activeQuiz.questionEn}</span>
                      <button
                        onClick={() => speakText(activeQuiz.questionEn || '')}
                        className="text-emerald-400 hover:text-emerald-300 p-1"
                        title="استمع للنطق"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Options */}
                <div className="space-y-2">
                  {activeQuiz.options.map((opt, idx) => {
                    const isSelected = selectedOption === opt;
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          setSelectedOption(opt);
                          setQuizResult(null);
                        }}
                        className={`w-full p-3.5 rounded-2xl border-b-4 text-right font-en font-bold text-sm transition ${
                          isSelected
                            ? 'bg-emerald-600 border-emerald-800 text-white shadow-md'
                            : 'bg-emerald-950/80 hover:bg-emerald-900/60 border-emerald-900 text-emerald-100'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>

                {/* Feedback */}
                {quizResult === 'correct' && (
                  <div className="bg-emerald-900/80 border border-emerald-500 rounded-2xl p-3.5 text-center">
                    <span className="text-xs font-black text-emerald-300 flex items-center justify-center gap-1 mb-1">
                      <Check className="w-4 h-4 text-emerald-400" />
                      أحسنت! إجابة ممتازة ودقيقة جداً
                    </span>
                    <p className="text-xs text-emerald-200">{activeQuiz.explanationAr}</p>
                  </div>
                )}

                {quizResult === 'wrong' && (
                  <div className="bg-rose-950/80 border border-rose-700 rounded-2xl p-3.5 text-center">
                    <span className="text-xs font-black text-rose-300 flex items-center justify-center gap-1 mb-1">
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                      إجابة غير صحيحة، فقدت قلباً واحداً!
                    </span>
                    <p className="text-xs text-rose-200">{activeQuiz.explanationAr}</p>
                  </div>
                )}

                {/* Action button */}
                {quizResult === 'correct' ? (
                  <button
                    onClick={() => setSelectedNode(null)}
                    className="w-full duo-btn-green text-white font-black text-sm py-3 rounded-2xl cursor-pointer"
                  >
                    متابعة المسار
                  </button>
                ) : (
                  <button
                    onClick={handleCheckQuizAnswer}
                    disabled={!selectedOption || hearts <= 0}
                    className="w-full duo-btn-green disabled:opacity-50 text-white font-black text-sm py-3 rounded-2xl cursor-pointer"
                  >
                    {hearts <= 0 ? 'نفدت القلوب! اشترِ قلوباً من المتجر' : 'تحقق من الإجابة'}
                  </button>
                )}
              </div>
            ) : (
              /* Lesson Overview inside node modal */
              <div className="space-y-4">
                {(() => {
                  const lessonObj = INITIAL_LESSONS.find((l) => l.dayNumber === selectedNode.dayNumber) || INITIAL_LESSONS[0];
                  return (
                    <div>
                      <div className="bg-emerald-950/80 p-4 rounded-2xl border border-emerald-800 mb-3">
                        <span className="text-xs font-bold text-amber-400 block mb-1">هدف اليوم:</span>
                        <p className="text-xs text-white leading-relaxed">{lessonObj.descriptionAr}</p>
                      </div>

                      <div className="bg-emerald-950/60 p-4 rounded-2xl border border-emerald-800 mb-4">
                        <span className="text-xs font-bold text-emerald-400 block mb-1">القاعدة النحوية:</span>
                        <p className="text-xs text-emerald-200 mb-3">{lessonObj.grammarRuleAr}</p>

                        <span className="text-xs font-bold text-cyan-300 block mb-1.5">أمثلة نطق ومحادثة:</span>
                        <div className="space-y-2">
                          {lessonObj.grammarExamples.map((ex, i) => (
                            <div key={i} className="flex items-center justify-between bg-[#071a0e] p-2.5 rounded-xl border border-emerald-900/60">
                              <span className="text-xs font-en text-emerald-100 font-medium dir-ltr text-left">{ex}</span>
                              <button
                                onClick={() => speakText(ex)}
                                className="text-emerald-400 hover:text-emerald-300 p-1"
                                title="استمع للنطق"
                              >
                                <Volume2 className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          onNodeComplete(selectedNode.id);
                          onAddXp(selectedNode.xpReward);
                          setSelectedNode(null);
                          confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
                        }}
                        className="w-full duo-btn-green text-white font-black text-sm py-3 rounded-2xl cursor-pointer flex items-center justify-center gap-2"
                      >
                        <Check className="w-5 h-5" />
                        <span>إكمال الدرس ونيل +{selectedNode.xpReward} XP</span>
                      </button>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
