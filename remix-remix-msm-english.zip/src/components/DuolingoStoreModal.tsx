import { FC } from 'react';
import { Heart, Sparkles, X, Shield, RefreshCw, MessageCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface DuolingoStoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  hearts: number;
  gems: number;
  onRefillHearts: () => void;
  onSpendGems: (amount: number) => boolean;
}

export const DuolingoStoreModal: FC<DuolingoStoreModalProps> = ({
  isOpen,
  onClose,
  hearts,
  gems,
  onRefillHearts,
  onSpendGems,
}) => {
  if (!isOpen) return null;

  const handleBuyHearts = () => {
    if (gems >= 50) {
      const ok = onSpendGems(50);
      if (ok) {
        onRefillHearts();
        confetti({ particleCount: 50, spread: 60 });
      }
    } else {
      // Free practice refill
      onRefillHearts();
      confetti({ particleCount: 30, spread: 50 });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0b2314] border-2 border-emerald-600 rounded-3xl max-w-md w-full p-6 shadow-2xl text-right text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-emerald-900 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-lg text-white">متجر المكافآت والقلوب</h3>
              <p className="text-xs text-emerald-400">حافظ على صحتك وحماسك في اللعبة</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-300 hover:text-white flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balances */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <div className="bg-emerald-950/80 p-3 rounded-2xl border border-emerald-800 text-center">
            <span className="text-xs text-emerald-400 block mb-1">القلوب المتوفرة</span>
            <div className="flex items-center justify-center gap-1.5 text-rose-400 font-black text-lg">
              <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
              <span>{hearts} / 5</span>
            </div>
          </div>

          <div className="bg-emerald-950/80 p-3 rounded-2xl border border-emerald-800 text-center">
            <span className="text-xs text-emerald-400 block mb-1">رصيد الجواهر</span>
            <div className="flex items-center justify-center gap-1.5 text-cyan-300 font-black text-lg">
              <span>💎 {gems}</span>
            </div>
          </div>
        </div>

        {/* Store Items */}
        <div className="space-y-3 mb-6">
          {/* Item 1: Full Heart Refill */}
          <div className="bg-[#12361e] border border-emerald-700/60 rounded-2xl p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                <Heart className="w-6 h-6 fill-rose-500" />
              </div>
              <div>
                <h4 className="text-sm font-black text-white">شحن كامل للقلوب (5/5)</h4>
                <p className="text-xs text-emerald-300">استرجع كامل طاقتك لمواصلة التحديات</p>
              </div>
            </div>

            <button
              onClick={handleBuyHearts}
              disabled={hearts >= 5}
              className="duo-btn-green disabled:opacity-50 text-white font-black text-xs px-3.5 py-2 rounded-xl cursor-pointer whitespace-nowrap"
            >
              {hearts >= 5 ? 'ممتلئة' : gems >= 50 ? '50 💎' : 'شحن مجاني'}
            </button>
          </div>

          {/* Item 2: Streak Freeze */}
          <div className="bg-[#12361e] border border-emerald-700/60 rounded-2xl p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-black text-white">تجميد السلسلة (حماية اليوم)</h4>
                <p className="text-xs text-emerald-300">يحمي سلسلتك اليومية من الضياع إذا انشغلت</p>
              </div>
            </div>

            <button
              onClick={() => {
                if (gems >= 20) {
                  onSpendGems(20);
                  confetti({ particleCount: 40 });
                }
              }}
              className="duo-btn-blue text-white font-black text-xs px-3.5 py-2 rounded-xl cursor-pointer whitespace-nowrap"
            >
              20 💎
            </button>
          </div>
        </div>

        {/* Developer Contact Footer */}
        <div className="bg-[#381605] border border-amber-800/80 rounded-2xl p-3 text-center text-amber-200">
          <p className="text-xs font-bold mb-1">صانع التطبيق: محمد صالح مهاجر</p>
          <a
            href="https://wa.me/23566421752"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 text-xs text-amber-300 hover:text-white font-mono underline"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>واتساب: +23566421752</span>
          </a>
        </div>
      </div>
    </div>
  );
};
