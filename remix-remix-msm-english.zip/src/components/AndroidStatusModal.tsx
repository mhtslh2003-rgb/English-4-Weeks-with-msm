import { FC } from 'react';
import { 
  X, Smartphone, CheckCircle, FolderTree, Cpu, Music, ShieldCheck, 
  Download, AlertTriangle, MessageCircle, HelpCircle, ExternalLink, Flame
} from 'lucide-react';

interface AndroidStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerInstallPWA?: () => void;
  isInstallable?: boolean;
}

export const AndroidStatusModal: FC<AndroidStatusModalProps> = ({ 
  isOpen, 
  onClose,
  onTriggerInstallPWA,
  isInstallable
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#0b2314] border-2 border-emerald-600 rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-5 sm:p-7 shadow-2xl text-right text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-emerald-900 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600/30 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
              <Smartphone className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-white font-black text-lg sm:text-xl">دليل استخراج وتثبيت التطبيق على أندرويد (APK)</h3>
              <p className="text-xs text-emerald-300">تطبيق MSM ENGLISH • تطوير: محمد صالح مهاجر</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-emerald-950 text-emerald-300 hover:text-white flex items-center justify-center transition border border-emerald-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Reason for "البيانات غير موجودة" in external converter websites */}
        <div className="bg-[#381605] border-2 border-amber-700/80 rounded-2xl p-4 mb-5">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-black text-amber-200">
                لماذا قالت مواقع التحويل الخارجية "البيانات غير موجودة"؟
              </h4>
              <p className="text-xs text-amber-100/90 leading-relaxed mt-1">
                مواقع تحويل الويب العادية (مثل Web2APK القديمة) تتطلب رابطاً ثابتاً وملف <code className="bg-black/40 px-1.5 py-0.5 rounded text-amber-300">manifest.json</code> وأيقونات محددة بدقة. تم الآن تضمين وضبط نظام PWA Manifest + كاش العمل أوفلاين بالكامل، بالإضافة لمشروع أندرويد الأصلي المتكامل في مجلد <code className="bg-black/40 px-1.5 py-0.5 rounded text-amber-300">/app</code>!
              </p>
            </div>
          </div>
        </div>

        {/* Method 1: Instant PWA Install on Android */}
        <div className="bg-gradient-to-br from-emerald-900/90 to-green-950 border-2 border-emerald-500 rounded-2xl p-4 mb-5">
          <div className="flex items-center justify-between gap-3 mb-2">
            <span className="text-xs font-black bg-emerald-500 text-emerald-950 px-2.5 py-0.5 rounded-full">
              الطريقة الأسهل والفورية ⭐
            </span>
            <span className="text-xs text-emerald-300 font-bold">تعمل كـ تطبيق أندرويد 100%</span>
          </div>

          <h4 className="text-base font-black text-white mb-1">
            التثبيت المباشر على الهاتف (PWA بنظام شاشة كاملة وأوفلاين)
          </h4>
          <p className="text-xs text-emerald-100/90 mb-4 leading-relaxed">
            عند فتح هذا التطبيق في متصفح جوجل كروم على هاتفك، انقر على زر التثبيت أدناه أو افتح قائمة كروم (⋮) واختر <strong>"إضافة إلى الشاشة الرئيسية" (Install / Add to Home Screen)</strong>. سيظهر التطبيق فوراً كبرنامج مستقل على شاشة هاتفك مع أيقونته الرسمية ويعمل بدون الحاجة لأي إنترنت!
          </p>

          {onTriggerInstallPWA && isInstallable && (
            <button
              onClick={onTriggerInstallPWA}
              className="w-full duo-btn-green text-white font-black text-sm py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer mb-2"
            >
              <Download className="w-4 h-4" />
              <span>تثبيت التطبيق الآن على هذا الجهاز</span>
            </button>
          )}
        </div>

        {/* Method 2: Building Real Android APK */}
        <div className="bg-[#12361e] border border-emerald-700/60 rounded-2xl p-4 mb-5">
          <h4 className="text-sm font-black text-white mb-2 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>استخراج ملف الـ APK الأصلي عبر Android Studio:</span>
          </h4>
          <p className="text-xs text-emerald-200 mb-3 leading-relaxed">
            المشروع يحتوي بالفعل على كود تطبيقي كامل بلغة Kotlin و Jetpack Compose داخل مجلد <code className="text-amber-300 font-mono">/app</code>. يمكنك تنزيل ملفات المشروع (ZIP) وفتحها في برنامج Android Studio ثم الضغط على Build APK:
          </p>

          <div className="bg-black/50 rounded-xl p-3 border border-emerald-900 font-mono text-xs text-left dir-ltr mb-3">
            <span className="text-slate-400"># أمر بناء ملف الـ APK عبر موجه الأوامر:</span>
            <p className="text-amber-300 mt-1 font-bold">./gradlew assembleDebug</p>
            <span className="text-slate-400 block mt-2"># موقع ملف الـ APK الناتج:</span>
            <p className="text-emerald-400 mt-0.5">app/build/outputs/apk/debug/app-debug.apk</p>
          </div>
        </div>

        {/* Verified Native Files */}
        <div className="bg-[#071a0e] rounded-2xl p-4 border border-emerald-900 mb-5">
          <div className="flex items-center gap-2 text-xs font-black text-emerald-400 mb-2">
            <FolderTree className="w-4 h-4" />
            <span>بيانات وتجهيزات الأندرويد المؤكدة:</span>
          </div>
          <ul className="text-xs text-emerald-200/90 space-y-1.5 list-disc list-inside">
            <li><strong>6 تسجيلات صوتية تحفيزية</strong> مدمجة في مجلد <code className="text-amber-300 font-mono">app/src/main/res/raw/</code></li>
            <li><strong>أيقونة التطبيق الرسمية</strong> مدمجة في جميع مقاسات <code className="text-amber-300 font-mono">res/mipmap/</code> و <code className="text-amber-300 font-mono">/public</code></li>
            <li><strong>قاعدة بيانات Room المحلية</strong> تعمل أوفلاين 100% بدون حاجة لخادم</li>
            <li><strong>ملف Manifest الأصلي</strong> مُسجل باسم MSM ENGLISH وحزمته الرسمية</li>
          </ul>
        </div>

        {/* Developer Contact Card */}
        <div className="bg-gradient-to-r from-[#3b1506] to-[#260e04] border-2 border-amber-700/80 rounded-2xl p-4 text-center sm:text-right flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-black text-amber-300 block">صانع ومطور التطبيق:</span>
            <h4 className="text-base font-black text-white">محمد صالح مهاجر</h4>
            <p className="text-xs text-amber-200 font-mono dir-ltr">+23566421752</p>
          </div>

          <a
            href="https://wa.me/23566421752"
            target="_blank"
            rel="noreferrer"
            className="duo-btn-green text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            <span>تواصل مباشرة عبر واتساب</span>
          </a>
        </div>
      </div>
    </div>
  );
};

