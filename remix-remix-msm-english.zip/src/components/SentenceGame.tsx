import { FC, useState } from 'react';
import { Sparkles, Check, RefreshCw, Trophy, Volume2, Heart, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { SENTENCE_PUZZLES } from '../data/mockData';

interface SentenceGameProps {
  onAddXp: (amount: number) => void;
  onDeductHeart?: () => void;
}

export const SentenceGame: FC<SentenceGameProps> = ({ onAddXp, onDeductHeart }) => {
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const currentPuzzle = SENTENCE_PUZZLES[puzzleIndex];

  const [availableWords, setAvailableWords] = useState<string[]>([...currentPuzzle.wordsScrambled]);
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const resetForPuzzle = (index: number) => {
    setPuzzleIndex(index);
    setAvailableWords([...SENTENCE_PUZZLES[index].wordsScrambled]);
    setSelectedWords([]);
    setIsCorrect(null);
  };

  const handlePickWord = (word: string, index: number) => {
    const newAvail = [...availableWords];
    newAvail.splice(index, 1);
    setAvailableWords(newAvail);
    setSelectedWords([...selectedWords, word]);
    setIsCorrect(null);
  };

  const handleUnpickWord = (word: string, index: number) => {
    const newSelected = [...selectedWords];
    newSelected.splice(index, 1);
    setSelectedWords(newSelected);
    setAvailableWords([...availableWords, word]);
    setIsCorrect(null);
  };

  const speakSentence = (sentence: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(sentence);
      u.lang = 'en-US';
      u.rate = 0.85;
      window.speechSynthesis.speak(u);
    }
  };

  const checkAnswer = () => {
    const constructed = selectedWords.join(' ');
    if (constructed.trim().toLowerCase() === currentPuzzle.correctSentence.trim().toLowerCase()) {
      setIsCorrect(true);
      onAddXp(currentPuzzle.xpReward);
      speakSentence(currentPuzzle.correctSentence);
      confetti({
        particleCount: 70,
        spread: 75,
        origin: { y: 0.75 }
      });
    } else {
      setIsCorrect(false);
      if (onDeductHeart) {
        onDeductHeart();
      }
    }
  };

  return (
    <div className="bg-[#0b2314] border-2 border-emerald-600 rounded-3xl p-5 sm:p-7 shadow-xl text-white">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-white font-black text-lg sm:text-xl">لعبة تركيب الجمل التفاعلية</h3>
            <span className="text-[11px] bg-amber-400 text-amber-950 font-black px-2 py-0.5 rounded-md">
              Duolingo Style
            </span>
          </div>
          <p className="text-xs text-emerald-300 mt-0.5">
            اللغز {puzzleIndex + 1} من {SENTENCE_PUZZLES.length} • رتّب الكلمات الإنجليزية بدقة
          </p>
        </div>
        <div className="flex items-center gap-1.5 bg-[#3d2407] border border-amber-600 text-amber-300 px-3 py-1.5 rounded-xl text-xs font-black shadow">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>+{currentPuzzle.xpReward} XP</span>
        </div>
      </div>

      {/* Target prompt in Arabic: Dark Brown / Burgundy Card */}
      <div className="bg-gradient-to-r from-[#2c1005] to-[#3d1a08] border-2 border-amber-800 rounded-2xl p-4 text-center mb-5 shadow-inner">
        <span className="text-[11px] font-black text-amber-400 block mb-1">المعنى المطلوب ترجمته:</span>
        <p className="text-amber-100 font-black text-base sm:text-lg leading-relaxed">{currentPuzzle.promptAr}</p>
      </div>

      {/* Answer Drop Area */}
      <div className="min-h-20 bg-[#071a0e] border-2 border-dashed border-emerald-600/70 rounded-2xl p-3 sm:p-4 mb-4 flex flex-wrap items-center justify-center gap-2.5 shadow-inner">
        {selectedWords.length === 0 ? (
          <span className="text-xs text-emerald-600 italic">انقر على الكلمات بالترتيب لتضعها هنا</span>
        ) : (
          selectedWords.map((word, idx) => (
            <button
              key={`${word}-${idx}`}
              onClick={() => handleUnpickWord(word, idx)}
              className="duo-btn-green text-white font-en text-sm font-black px-3.5 py-2 rounded-xl shadow cursor-pointer"
            >
              {word}
            </button>
          ))
        )}
      </div>

      {/* Scrambled Word Bank */}
      <div className="flex flex-wrap items-center justify-center gap-2.5 mb-6 min-h-12">
        {availableWords.map((word, idx) => (
          <button
            key={`${word}-${idx}`}
            onClick={() => handlePickWord(word, idx)}
            className="duo-btn-brown text-amber-100 font-en text-sm font-black px-3.5 py-2 rounded-xl cursor-pointer active:scale-95 shadow"
          >
            {word}
          </button>
        ))}
      </div>

      {/* Feedback & Actions */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-emerald-900">
        <button
          onClick={() => resetForPuzzle(puzzleIndex)}
          className="flex items-center gap-1.5 text-xs text-emerald-300 hover:text-white transition px-3 py-2 rounded-xl bg-emerald-950 border border-emerald-800 cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>إعادة ترتيب الكلمات</span>
        </button>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          {isCorrect === true && (
            <div className="flex items-center gap-2 text-xs text-emerald-300 font-black">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>إجابة صحيحة ورائعة!</span>
              <button
                onClick={() => speakSentence(currentPuzzle.correctSentence)}
                className="p-1 text-emerald-300 hover:text-white"
                title="استمع للجملة"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          )}

          {isCorrect === false && (
            <span className="text-xs text-rose-400 font-black flex items-center gap-1">
              <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
              حاول مجدداً، الترتيب غير دقيق!
            </span>
          )}

          {isCorrect === true ? (
            puzzleIndex < SENTENCE_PUZZLES.length - 1 ? (
              <button
                onClick={() => resetForPuzzle(puzzleIndex + 1)}
                className="duo-btn-yellow text-amber-950 text-xs font-black px-5 py-2.5 rounded-xl cursor-pointer flex items-center gap-1"
              >
                <span>اللغز التالي</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={() => resetForPuzzle(0)}
                className="duo-btn-green text-white text-xs font-black px-5 py-2.5 rounded-xl cursor-pointer"
              >
                🎉 إنهاء وإعادة من البداية
              </button>
            )
          ) : (
            <button
              onClick={checkAnswer}
              disabled={selectedWords.length === 0}
              className="duo-btn-green disabled:opacity-50 text-white text-xs font-black px-6 py-2.5 rounded-xl cursor-pointer shadow"
            >
              تحقق من الإجابة
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

