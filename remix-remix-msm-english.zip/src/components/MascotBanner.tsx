import { FC } from 'react';
import { Sparkles, MessageCircle, Phone, Smartphone, Flame, Heart, Award, ArrowLeft } from 'lucide-react';

interface MascotBannerProps {
  streak: number;
  hearts: number;
  gems: number;
  onOpenAndroidExport: () => void;
  onOpenStore: () => void;
}

export const MascotBanner: FC<MascotBannerProps> = ({
  streak,
  hearts,
  gems,
  onOpenAndroidExport,
  onOpenStore,
}) => {
  return (
    <div className="bg-gradient-to-r from-emerald-900 via-green-900 to-emerald-950 border-2 border-emerald-600/50 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden text-white">
      {/* Decorative background glow */}
      <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -right-10 -top-10 w-40 h-40 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Mascot & Greeting Bubble */}
        <div className="flex items-center gap-4 text-right">
          {/* Duolingo Inspired Owl Mascot Icon */}
          <div className="relative shrink-0">
            <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-tr from-emerald-500 to-green-400 p-1 shadow-lg shadow-emerald-950/60 flex items-center justify-center border-2 border-emerald-300">
              <img
                src="/icon-192.png"
                alt="MSM ENGLISH Mascot"
                className="w-full h-full object-cover rounded-2xl"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            {/* Online badge */}
            <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-amber-400 rounded-full border-2 border-emerald-950 flex items-center justify-center text-[10px] font-black text-amber-950">
              ✓
            </span>
          </div>

          {/* Dialog Bubble */}
          <div className="bg-[#0b2915] border-2 border-emerald-500/60 rounded-2xl p-3.5 shadow-md max-w-md relative">
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-amber-400 text-amber-950 text-[10px] font-black px-2 py-0.5 rounded-full">
                تحفيز دولينجو اليومي
              </span>
              <span className="text-xs text-emerald-300 font-bold">15 دقيقة فقط تصنع المعجزة!</span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-100 font-bold leading-relaxed">
              "أهلاً بك! تعلم معي خطوة بخطوة باللعب والتكرار. جمع النجوم وحافظ على قلوبك وسلسلة حماسك اليومية!"
            </p>
          </div>
        </div>

        {/* Developer Attribution & Contact Badge */}
        <div className="bg-gradient-to-b from-[#3d1a08] to-[#240e04] border-2 border-amber-800/80 rounded-2xl p-4 shadow-lg flex flex-col items-center sm:items-end text-center sm:text-right shrink-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-black bg-amber-500/20 text-amber-300 border border-amber-600/40 px-2 py-0.5 rounded-md">
              مطور وصانع التطبيق
            </span>
          </div>
          <h4 className="text-base font-black text-amber-100 mb-0.5">محمد صالح مهاجر</h4>
          <p className="text-xs text-amber-200/80 font-mono dir-ltr mb-3 flex items-center gap-1">
            <Phone className="w-3.5 h-3.5 text-emerald-400 inline" />
            <span>+23566421752</span>
          </p>

          <div className="flex items-center gap-2 w-full">
            <a
              href="https://wa.me/23566421752"
              target="_blank"
              rel="noreferrer"
              className="flex-1 duo-btn-green text-white font-bold text-xs px-3 py-2 rounded-xl flex items-center justify-center gap-1.5 shadow"
              title="محادثة صانع التطبيق محمد صالح مهاجر على واتساب"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>واتساب المطور</span>
            </a>

            <button
              onClick={onOpenAndroidExport}
              className="duo-btn-brown text-amber-100 font-bold text-xs px-3 py-2 rounded-xl flex items-center justify-center gap-1.5 shadow"
              title="تنزيل واستخراج APK وأوفلاين"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>استخراج APK</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
