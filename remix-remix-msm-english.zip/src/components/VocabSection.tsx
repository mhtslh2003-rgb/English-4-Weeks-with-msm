import { FC, useState } from 'react';
import { Volume2, CheckCircle2, RotateCw, BookA, Sparkles } from 'lucide-react';
import { VocabWord } from '../types';

interface VocabSectionProps {
  vocabList: VocabWord[];
  onToggleMastered: (id: string) => void;
}

export const VocabSection: FC<VocabSectionProps> = ({ vocabList, onToggleMastered }) => {
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});

  const toggleFlip = (id: string) => {
    setFlippedCards((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const speakWord = (word: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.lang = 'en-US';
      utterance.rate = 0.85;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="bg-[#0b2314] border-2 border-emerald-600 rounded-3xl p-5 sm:p-7 shadow-xl text-white">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-white font-black text-lg sm:text-xl">بنك المفردات والبطاقات التفاعلية</h3>
            <span className="text-[10px] bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full font-black">
              SRS Engine
            </span>
          </div>
          <p className="text-xs text-emerald-300 mt-0.5">
            انقر على البطاقة لقلبها، واستمع لنطق الكلمة بالإنجليزية وحفظها في ذاكرتك
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {vocabList.map((item) => {
          const isFlipped = Boolean(flippedCards[item.id]);

          return (
            <div
              key={item.id}
              className={`rounded-2xl border-2 p-4 transition-all duration-200 cursor-pointer ${
                item.isMastered
                  ? 'bg-[#123820] border-emerald-400 shadow-md'
                  : 'bg-[#06170d] border-emerald-900 hover:border-emerald-700'
              }`}
              onClick={() => toggleFlip(item.id)}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-[#3d1a08] text-amber-300 border border-amber-700/60 px-2 py-0.5 rounded-md">
                    {item.category}
                  </span>
                  <span className="text-[10px] text-emerald-400 font-medium">{item.partOfSpeech}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      speakWord(item.word);
                    }}
                    className="w-8 h-8 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 flex items-center justify-center transition border border-emerald-500/40 cursor-pointer"
                    title="استمع للنطق الإنجليزي"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleMastered(item.id);
                    }}
                    className={`w-8 h-8 rounded-lg flex items-center justify-center transition border cursor-pointer ${
                      item.isMastered
                        ? 'bg-emerald-500 text-emerald-950 border-emerald-400'
                        : 'bg-emerald-950 text-emerald-600 border-emerald-900 hover:text-emerald-300'
                    }`}
                    title={item.isMastered ? 'تم إتقانها' : 'تعليم كمتقنة'}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {!isFlipped ? (
                <div>
                  <h4 className="text-white text-lg font-black font-en mb-0.5 text-left dir-ltr">{item.word}</h4>
                  <p className="text-xs text-amber-400 font-mono text-left dir-ltr mb-2">{item.phonetic}</p>
                  <p className="text-sm text-emerald-100 font-bold">{item.translationAr}</p>
                  <div className="mt-3 flex items-center justify-between text-[11px] text-emerald-400/80 border-t border-emerald-900/60 pt-2">
                    <span className="flex items-center gap-1">
                      <RotateCw className="w-3 h-3" />
                      انقر للتعريف والمثال
                    </span>
                    <span className="bg-emerald-950 px-2 py-0.5 rounded text-[10px] font-bold">{item.difficulty}</span>
                  </div>
                </div>
              ) : (
                <div>
                  <p className="text-xs text-emerald-100 font-en text-left dir-ltr leading-relaxed mb-2">
                    <span className="font-bold text-amber-300">Definition: </span>
                    {item.definitionEn}
                  </p>
                  <div className="bg-[#040e08] p-2.5 rounded-xl border border-emerald-900 text-left dir-ltr font-en">
                    <p className="text-xs text-amber-200 italic leading-snug">"{item.exampleEn}"</p>
                  </div>
                  <div className="mt-3 flex items-center justify-between text-[11px] text-emerald-400/80 border-t border-emerald-900/60 pt-2">
                    <span className="flex items-center gap-1">
                      <RotateCw className="w-3 h-3" />
                      انقر للعودة
                    </span>
                    <span className="text-amber-400 font-bold">{item.translationAr}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

