import { FC, useState } from 'react';
import { CheckCircle2, Circle, Clock, Award, BookOpen, ChevronDown, ChevronUp, Volume2 } from 'lucide-react';
import { Lesson } from '../types';

interface LessonListProps {
  lessons: Lesson[];
  onToggleLesson: (dayNumber: number) => void;
}

export const LessonList: FC<LessonListProps> = ({ lessons, onToggleLesson }) => {
  const [expandedDay, setExpandedDay] = useState<number | null>(1);

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US';
      u.rate = 0.85;
      window.speechSynthesis.speak(u);
    }
  };

  return (
    <div className="bg-[#0b2314] border-2 border-emerald-600 rounded-3xl p-5 sm:p-7 shadow-xl text-white">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-white font-black text-lg sm:text-xl">المنهج التعليمي الكامل (28 يوماً)</h3>
          <p className="text-xs text-emerald-300">دروس تفاعلية ومحفوظة بالكامل للعمل أوفلاين كخريطة طريق متكاملة</p>
        </div>
        <div className="text-xs text-amber-300 font-bold bg-[#3d1a08] border border-amber-700/60 px-3 py-1 rounded-xl">
          4 أسابيع تدريبية
        </div>
      </div>

      <div className="space-y-3">
        {lessons.map((lesson) => {
          const isExpanded = expandedDay === lesson.dayNumber;
          return (
            <div
              key={lesson.dayNumber}
              className={`rounded-2xl border-2 transition overflow-hidden ${
                lesson.isCompleted
                  ? 'bg-[#123820] border-emerald-400/80 shadow-md'
                  : 'bg-[#06170d] border-emerald-900 hover:border-emerald-700'
              }`}
            >
              {/* Row Header */}
              <div
                onClick={() => setExpandedDay(isExpanded ? null : lesson.dayNumber)}
                className="p-4 flex items-center justify-between gap-3 cursor-pointer select-none"
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleLesson(lesson.dayNumber);
                    }}
                    className="text-emerald-400 hover:text-emerald-300 transition cursor-pointer"
                    title={lesson.isCompleted ? 'إلغاء التحديد' : 'تعليم كمكتمل'}
                  >
                    {lesson.isCompleted ? (
                      <CheckCircle2 className="w-6 h-6 fill-emerald-500 text-emerald-950" />
                    ) : (
                      <Circle className="w-6 h-6 text-emerald-800 hover:text-emerald-500" />
                    )}
                  </button>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-amber-400">اليوم {lesson.dayNumber}</span>
                      <h4 className="text-white text-sm font-bold">{lesson.titleAr}</h4>
                    </div>
                    <p className="text-xs text-emerald-300 font-en">{lesson.titleEn}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="hidden sm:flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{lesson.durationMinutes} د</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-amber-300 font-black bg-[#3d2407] px-2 py-0.5 rounded-lg border border-amber-700">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    <span>+{lesson.xpReward} XP</span>
                  </div>
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-emerald-400" /> : <ChevronDown className="w-4 h-4 text-emerald-400" />}
                </div>
              </div>

              {/* Expanded details */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-emerald-900 bg-[#040e08] text-right">
                  <p className="text-xs text-emerald-100 mb-3 leading-relaxed">{lesson.descriptionAr}</p>

                  <div className="bg-[#0b2414] rounded-xl p-3 border border-emerald-800 mb-3">
                    <span className="text-[11px] font-black text-amber-400 block mb-1">القاعدة النحوية المستهدفة:</span>
                    <p className="text-xs text-emerald-200 leading-relaxed">{lesson.grammarRuleAr}</p>
                  </div>

                  <div className="bg-[#0b2414] rounded-xl p-3 border border-emerald-800">
                    <span className="text-[11px] font-black text-emerald-300 block mb-2">أمثلة المحادثة العملية (مع الصوت):</span>
                    <div className="space-y-1.5">
                      {lesson.grammarExamples.map((ex, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-[#040e08] p-2 rounded-lg border border-emerald-900/70">
                          <span className="text-xs text-emerald-100 font-en text-left dir-ltr font-medium">{ex}</span>
                          <button
                            onClick={() => speakText(ex)}
                            className="p-1 text-emerald-400 hover:text-emerald-200 cursor-pointer"
                            title="استمع للنطق الإنجليزي"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

