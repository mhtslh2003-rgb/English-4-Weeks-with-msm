import { FC } from 'react';
import { Flame, Sparkles, Heart, Smartphone, Download, Phone, MessageCircle } from 'lucide-react';
import { StudentProfile } from '../types';

interface HeaderProps {
  profile: StudentProfile;
  onOpenAndroidInfo: () => void;
  onOpenStore: () => void;
  isInstallable?: boolean;
  onInstallPWA?: () => void;
}

export const Header: FC<HeaderProps> = ({ 
  profile, 
  onOpenAndroidInfo,
  onOpenStore,
  isInstallable,
  onInstallPWA
}) => {
  return (
    <header className="bg-[#0b2414]/95 backdrop-blur-md border-b-2 border-emerald-800 sticky top-0 z-40 px-3 sm:px-4 py-2.5 shadow-md">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* App Branding & Developer Label */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="relative shrink-0">
            <img
              src="/icon-192.png"
              alt="MSM ENGLISH"
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl shadow-md border-2 border-emerald-400/60 object-cover"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-[#0b2414]" title="أوفلاين جاهز" />
          </div>

          <div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <h1 className="text-white font-black text-base sm:text-lg tracking-tight">MSM ENGLISH</h1>
              <span className="text-[10px] font-bold bg-amber-400 text-amber-950 px-1.5 py-0.2 rounded-md">
                دولينجو
              </span>
            </div>
            <p className="text-[11px] text-emerald-300 font-semibold truncate max-w-[140px] sm:max-w-none">
              صانع التطبيق: محمد صالح مهاجر
            </p>
          </div>
        </div>

        {/* Duolingo Gamified Status Bar: Hearts, Streak, Gems, XP, Install */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Hearts (Lives) */}
          <button
            onClick={onOpenStore}
            className="flex items-center gap-1 bg-[#3a1111] hover:bg-[#4d1717] border border-rose-700/60 text-rose-300 rounded-xl px-2 sm:px-2.5 py-1 text-xs font-black transition cursor-pointer shadow-sm"
            title="القلوب المتبقية - انقر للشحن"
          >
            <Heart className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-rose-500 text-rose-500 animate-pulse" />
            <span>{profile.hearts ?? 5}</span>
          </button>

          {/* Streak Flame */}
          <div 
            className="flex items-center gap-1 bg-[#3d2407] border border-amber-600/50 text-amber-400 rounded-xl px-2 sm:px-2.5 py-1 text-xs font-black shadow-sm"
            title="أيام الحماس المتتالية"
          >
            <Flame className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-amber-400 text-amber-400 animate-bounce" />
            <span className="hidden xs:inline">{profile.currentStreak}d</span>
          </div>

          {/* Gems (Diamonds) */}
          <button
            onClick={onOpenStore}
            className="flex items-center gap-1 bg-[#092938] hover:bg-[#0c374c] border border-sky-600/50 text-cyan-300 rounded-xl px-2 sm:px-2.5 py-1 text-xs font-black transition cursor-pointer shadow-sm"
            title="المجوهرات - انقر لفتح المتجر"
          >
            <span className="text-xs">💎</span>
            <span className="hidden sm:inline">{profile.gems ?? 120}</span>
          </button>

          {/* XP */}
          <div 
            className="hidden md:flex items-center gap-1 bg-emerald-950 border border-emerald-600/40 text-emerald-300 rounded-xl px-2.5 py-1 text-xs font-black"
            title="مجموع نقاط الـ XP"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{profile.totalXp} XP</span>
          </div>

          {/* PWA Install Button if available */}
          {isInstallable && onInstallPWA && (
            <button
              onClick={onInstallPWA}
              className="duo-btn-green text-white rounded-xl px-2.5 py-1 text-xs font-black flex items-center gap-1 shadow cursor-pointer animate-pulse"
              title="تثبيت كـ تطبيق أندرويد فوري"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">تثبيت التطبيق</span>
            </button>
          )}

          {/* Android Export Info modal trigger */}
          <button
            onClick={onOpenAndroidInfo}
            className="duo-btn-brown text-amber-100 rounded-xl px-2 sm:px-2.5 py-1 text-xs font-black flex items-center gap-1 shadow cursor-pointer"
            title="معاينة واستخراج بيانات الأندرويد والـ APK"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">APK</span>
          </button>
        </div>
      </div>
    </header>
  );
};

