import { FC, useState, useRef, useEffect, ChangeEvent } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, Sparkles, Headphones, Radio, VolumeX } from 'lucide-react';
import { MOTIVATIONAL_TRACKS } from '../data/mockData';
import { MotivationalTrack } from '../types';

export const MotivationPlayer: FC = () => {
  const [tracks] = useState<MotivationalTrack[]>(MOTIVATIONAL_TRACKS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(15);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const activeTrack = tracks[currentIndex] || tracks[0];

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = activeTrack.audioUrl;
      audioRef.current.load();
      if (isPlaying) {
        audioRef.current.play().catch(() => {
          // If browser restricts audio, fall back to speech synthesis
          speakMotivationalSpeech(activeTrack.quoteEn);
        });
      }
    }
  }, [currentIndex]);

  const speakMotivationalSpeech = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US';
      u.rate = 0.85;
      u.onend = () => setIsPlaying(false);
      window.speechSynthesis.speak(u);
      setIsPlaying(true);
    }
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(() => {
        speakMotivationalSpeech(activeTrack.quoteEn);
      });
    }
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % tracks.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + tracks.length) % tracks.length);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      if (audioRef.current.duration && !isNaN(audioRef.current.duration)) {
        setDuration(audioRef.current.duration);
      }
    }
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const handleSeek = (e: ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
      setCurrentTime(val);
    }
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <section className="bg-[#0b2314] border-2 border-emerald-600 rounded-3xl p-5 sm:p-7 shadow-xl text-white">
      <audio
        ref={audioRef}
        src={activeTrack.audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleEnded}
        onError={() => {
          // Handled via speech synthesis fallback
        }}
        onLoadedMetadata={() => {
          if (audioRef.current && audioRef.current.duration) {
            setDuration(audioRef.current.duration);
          }
        }}
      />

      {/* Header of Motivation Section */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Headphones className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-white font-black text-lg sm:text-xl">التسجيلات الصوتية التحفيزية الحصرية</h2>
              <span className="text-[10px] font-black bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full">
                MSM ENGLISH
              </span>
            </div>
            <p className="text-xs text-emerald-300">طاقة متجددة بصوت ناطقين أصليين لتشجيعك يومياً كأنك في لعبة دولينجو</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-amber-300 bg-[#3d2407] border border-amber-600/50 rounded-xl px-3 py-1.5 font-bold">
          <Radio className="w-3.5 h-3.5 animate-pulse text-amber-400" />
          <span>مدمجة أوفلاين في التطبيق</span>
        </div>
      </div>

      {/* Main Active Player Container: Dark Red / Brown / Emerald styling */}
      <div className="bg-[#071a0e] border-2 border-emerald-800 rounded-2xl p-4 sm:p-6 mb-6 shadow-inner">
        <div className="flex flex-col md:flex-row items-center gap-6">
          {/* Animated Mascot Disc */}
          <div className="relative group shrink-0">
            <div className={`w-24 h-24 rounded-2xl bg-gradient-to-tr from-emerald-600 via-green-500 to-amber-400 p-1 shadow-lg shadow-emerald-950/60 flex items-center justify-center ${isPlaying ? 'scale-105 transition-transform duration-300' : ''}`}>
              <div className="w-full h-full bg-[#0b2414] rounded-[12px] flex flex-col items-center justify-center gap-1 text-center p-2">
                <Volume2 className={`w-8 h-8 ${isPlaying ? 'text-amber-400 animate-bounce' : 'text-emerald-400'}`} />
                <span className="text-[10px] font-black text-amber-300 tracking-wider uppercase">{activeTrack.voice}</span>
              </div>
            </div>
            {isPlaying && (
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-amber-500"></span>
              </span>
            )}
          </div>

          {/* Track Titles & Quote */}
          <div className="flex-1 text-center md:text-right">
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-1.5">
              <span className="text-xs font-black bg-[#3d1a08] text-amber-300 border border-amber-700/60 rounded-md px-2 py-0.5">
                التسجيل {currentIndex + 1} من {tracks.length}
              </span>
              <span className="text-xs text-emerald-400 font-medium font-en">{activeTrack.titleEn}</span>
            </div>

            <h3 className="text-white font-black text-lg sm:text-xl mb-1">{activeTrack.titleAr}</h3>
            <p className="text-xs text-emerald-300 mb-3">{activeTrack.subtitleAr}</p>

            {/* Transcript Quote Box */}
            <div className="bg-[#12361e] border border-emerald-700/60 rounded-xl p-3 text-right">
              <p className="text-xs sm:text-sm text-amber-200 font-bold leading-relaxed font-en text-left mb-1.5 dir-ltr">
                "{activeTrack.quoteEn}"
              </p>
              <p className="text-xs text-emerald-100 leading-relaxed font-ar">
                {activeTrack.quoteAr}
              </p>
            </div>
          </div>
        </div>

        {/* Progress Timeline */}
        <div className="mt-5 pt-4 border-t border-emerald-900">
          <div className="flex items-center justify-between text-[11px] text-emerald-400 mb-1.5 font-mono">
            <span>{Math.floor(currentTime)}s</span>
            <span>{Math.floor(duration)}s</span>
          </div>

          <div className="relative w-full h-2.5 bg-emerald-950 rounded-full overflow-hidden mb-4 border border-emerald-900">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-yellow-400 transition-all duration-100"
              style={{ width: `${progressPercent}%` }}
            />
            <input
              type="range"
              min={0}
              max={duration || 15}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
          </div>

          {/* Duolingo Tactile Player Controls */}
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={handlePrev}
              className="w-11 h-11 rounded-2xl duo-btn-brown text-amber-100 flex items-center justify-center cursor-pointer shadow"
              title="التسجيل السابق"
            >
              <SkipBack className="w-5 h-5" />
            </button>

            <button
              onClick={togglePlay}
              className="w-16 h-16 rounded-3xl duo-btn-green text-white flex items-center justify-center cursor-pointer shadow-lg active:scale-95"
              title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل التسجيل'}
            >
              {isPlaying ? <Pause className="w-8 h-8 fill-white" /> : <Play className="w-8 h-8 fill-white ml-1" />}
            </button>

            <button
              onClick={handleNext}
              className="w-11 h-11 rounded-2xl duo-btn-brown text-amber-100 flex items-center justify-center cursor-pointer shadow"
              title="التسجيل التالي"
            >
              <SkipForward className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* All 6 Audio Tracks Cards */}
      <div>
        <h4 className="text-white font-black text-sm mb-3 flex items-center justify-between">
          <span>قائمة التسجيلات التحفيزية المتوفرة ({tracks.length})</span>
          <span className="text-xs text-emerald-400 font-normal">انقر للاستماع المباشر</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {tracks.map((track, idx) => {
            const isCurrent = idx === currentIndex;
            return (
              <button
                key={track.id}
                onClick={() => {
                  if (isCurrent) {
                    togglePlay();
                  } else {
                    setCurrentIndex(idx);
                    setIsPlaying(true);
                  }
                }}
                className={`flex items-center justify-between p-3.5 rounded-2xl border-2 text-right transition cursor-pointer ${
                  isCurrent
                    ? 'bg-[#12361e] border-emerald-400 text-white shadow-md'
                    : 'bg-[#071a0e] hover:bg-[#0c2b18] border-emerald-900 text-emerald-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                      isCurrent
                        ? 'duo-btn-green text-white'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                    }`}
                  >
                    {isCurrent && isPlaying ? (
                      <Pause className="w-4 h-4 fill-current" />
                    ) : (
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    )}
                  </div>
                  <div>
                    <p className={`text-xs font-black leading-snug ${isCurrent ? 'text-amber-300' : 'text-white'}`}>
                      {track.titleAr}
                    </p>
                    <p className="text-[11px] text-emerald-400 font-en">{track.titleEn}</p>
                  </div>
                </div>

                <div className="text-left flex flex-col items-end">
                  <span className="text-[11px] font-mono text-emerald-400">{track.durationSec}s</span>
                  <span className="text-[10px] text-amber-400 font-bold">{track.voice}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};

