export interface MotivationalTrack {
  id: string;
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  audioUrl: string;
  durationSec: number;
  voice: string;
  quoteEn: string;
  quoteAr: string;
}

export interface Lesson {
  dayNumber: number;
  weekNumber: number;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  durationMinutes: number;
  xpReward: number;
  isCompleted: boolean;
  grammarRuleAr: string;
  grammarExamples: string[];
}

export interface VocabWord {
  id: string;
  word: string;
  phonetic: string;
  partOfSpeech: string;
  definitionEn: string;
  translationAr: string;
  exampleEn: string;
  category: string;
  difficulty: 'Beginner' | 'Elementary' | 'Intermediate';
  isMastered?: boolean;
}

export interface SentencePuzzle {
  id: string;
  promptAr: string;
  wordsScrambled: string[];
  correctSentence: string;
  xpReward: number;
}

export interface StudentProfile {
  name: string;
  levelName: string;
  selectedField: string;
  totalXp: number;
  currentStreak: number;
  totalStars: number;
  levelNumber: number;
  completedLessonsCount: number;
  masteredVocabCount: number;
  hearts: number;
  maxHearts: number;
  gems: number;
}

export interface PathNode {
  id: string;
  unitNumber: number;
  dayNumber: number;
  titleAr: string;
  titleEn: string;
  type: 'lesson' | 'quiz' | 'chest' | 'boss' | 'audio';
  status: 'completed' | 'active' | 'locked';
  stars: number;
  colorType: 'green' | 'red' | 'brown' | 'gold' | 'blue';
  xpReward: number;
}

export interface QuizQuestion {
  id: string;
  promptAr: string;
  type: 'multiple-choice' | 'translate-en' | 'match' | 'audio';
  questionEn?: string;
  options: string[];
  correctAnswer: string;
  explanationAr: string;
  audioPrompt?: string;
}

