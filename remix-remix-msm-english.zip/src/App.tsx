import { FC, useState } from 'react';
import { Header } from './components/Header';
import { DuolingoPath } from './components/DuolingoPath';
import { MascotBanner } from './components/MascotBanner';
import { MotivationPlayer } from './components/MotivationPlayer';
import { LessonList } from './components/LessonList';
import { VocabSection } from './components/VocabSection';
import { SentenceGame } from './components/SentenceGame';
import { AndroidStatusModal } from './components/AndroidStatusModal';
import { DuolingoStoreModal } from './components/DuolingoStoreModal';
import { INITIAL_LESSONS, VOCABULARY_LIST, LEARNING_PATH_NODES } from './data/mockData';
import { StudentProfile, Lesson, VocabWord, PathNode } from './types';
import { usePWAInstall } from './hooks/usePWAInstall';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { 
  Compass, Headphones, BookOpen, Layers, Gamepad2, 
  MessageCircle, Phone, Smartphone, WifiOff, Heart
} from 'lucide-react';

export const App: FC = () => {
  const { isInstallable, install } = usePWAInstall();
  const isOnline = useOnlineStatus();

  const [profile, setProfile] = useState<StudentProfile>({
    name: 'محمد الصالح',
    levelName: 'المستوى التأسيسي (A1)',
    selectedField: 'المحادثة اليومية وتطوير المهارات',
    totalXp: 580,
    currentStreak: 5,
    totalStars: 21,
    levelNumber: 2,
    completedLessonsCount: 4,
    masteredVocabCount: 3,
    hearts: 5,
    gems: 140
  });

  const [pathNodes, setPathNodes] = useState<PathNode[]>(LEARNING_PATH_NODES);
  const [lessons, setLessons] = useState<Lesson[]>(INITIAL_LESSONS);
  const [vocabList, setVocabList] = useState<VocabWord[]>(VOCABULARY_LIST);
  const [activeTab, setActiveTab] = useState<'path' | 'motivation' | 'lessons' | 'games' | 'vocab'>('path');
  
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);
  const [isStoreModalOpen, setIsStoreModalOpen] = useState(false);

  const handleUpdateHearts = (updater: (prev: number) => number) => {
    setProfile((prev) => ({
      ...prev,
      hearts: updater(prev.hearts ?? 5)
    }));
  };

  const handleAddGems = (amount: number) => {
    setProfile((prev) => ({
      ...prev,
      gems: (prev.gems ?? 120) + amount
    }));
  };

  const handleSpendGems = (amount: number): boolean => {
    if ((profile.gems ?? 0) >= amount) {
      setProfile((prev) => ({
        ...prev,
        gems: (prev.gems ?? 0) - amount
      }));
      return true;
    }
    return false;
  };

  const handleRefillHearts = () => {
    setProfile((prev) => ({
      ...prev,
      hearts: 5
    }));
  };

  const handleAddXp = (amount: number) => {
    setProfile((p) => ({
      ...p,
      totalXp: p.totalXp + amount
    }));
  };

  const handleNodeComplete = (nodeId: string) => {
    setPathNodes((prev) => {
      let foundIndex = -1;
      const updated = prev.map((node, i) => {
        if (node.id === nodeId) {
          foundIndex = i;
          return { ...node, status: 'completed' as const, stars: 3 };
        }
        return node;
      });

      // Unlock next node
      if (foundIndex !== -1 && foundIndex + 1 < updated.length) {
        if (updated[foundIndex + 1].status === 'locked') {
          updated[foundIndex + 1] = { ...updated[foundIndex + 1], status: 'active' as const };
        }
      }
      return updated;
    });
  };

  const handleToggleLesson = (dayNumber: number) => {
    setLessons((prev) =>
      prev.map((l) => {
        if (l.dayNumber === dayNumber) {
          const nextState = !l.isCompleted;
          if (nextState) {
            setProfile((p) => ({
              ...p,
              totalXp: p.totalXp + l.xpReward,
              completedLessonsCount: p.completedLessonsCount + 1,
              totalStars: p.totalStars + 3
            }));
          } else {
            setProfile((p) => ({
              ...p,
              totalXp: Math.max(0, p.totalXp - l.xpReward),
              completedLessonsCount: Math.max(0, p.completedLessonsCount - 1)
            }));
          }
          return { ...l, isCompleted: nextState };
        }
        return l;
      })
    );
  };

  const handleToggleMasteredVocab = (id: string) => {
    setVocabList((prev) =>
      prev.map((v) => {
        if (v.id === id) {
          const nextMastered = !v.isMastered;
          if (nextMastered) {
            setProfile((p) => ({
              ...p,
              totalXp: p.totalXp + 20,
              masteredVocabCount: p.masteredVocabCount + 1
            }));
          } else {
            setProfile((p) => ({
              ...p,
              masteredVocabCount: Math.max(0, p.masteredVocabCount - 1)
            }));
          }
          return { ...v, isMastered: nextMastered };
        }
        return v;
      })
    );
  };

  return (
    <div className="min-h-screen bg-[#06170d] text-emerald-50 flex flex-col font-ar selection:bg-emerald-600 selection:text-white" dir="rtl">
      {/* Top Header */}
      <Header 
        profile={profile} 
        onOpenAndroidInfo={() => setIsAndroidModalOpen(true)}
        onOpenStore={() => setIsStoreModalOpen(true)}
        isInstallable={isInstallable}
        onInstallPWA={install}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-4 py-5 space-y-5">
        {/* Mascot & Developer Card */}
        <MascotBanner
          streak={profile.currentStreak}
          hearts={profile.hearts ?? 5}
          gems={profile.gems ?? 140}
          onOpenAndroidExport={() => setIsAndroidModalOpen(true)}
          onOpenStore={() => setIsStoreModalOpen(true)}
        />

        {/* Tactile Duolingo Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setActiveTab('path')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-black transition whitespace-nowrap cursor-pointer ${
              activeTab === 'path'
                ? 'duo-btn-green text-white shadow-md'
                : 'bg-[#0b2414] text-emerald-300 hover:text-white border-2 border-emerald-900'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>خريطة مسار اللعبة (Duolingo Path)</span>
          </button>

          <button
            onClick={() => setActiveTab('motivation')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-black transition whitespace-nowrap cursor-pointer ${
              activeTab === 'motivation'
                ? 'duo-btn-yellow text-amber-950 shadow-md'
                : 'bg-[#0b2414] text-emerald-300 hover:text-white border-2 border-emerald-900'
            }`}
          >
            <Headphones className="w-4 h-4" />
            <span>الصوتيات التحفيزية (6 تسجيلات)</span>
          </button>

          <button
            onClick={() => setActiveTab('games')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-black transition whitespace-nowrap cursor-pointer ${
              activeTab === 'games'
                ? 'duo-btn-red text-white shadow-md'
                : 'bg-[#0b2414] text-emerald-300 hover:text-white border-2 border-emerald-900'
            }`}
          >
            <Gamepad2 className="w-4 h-4" />
            <span>لعبة تركيب الجمل</span>
          </button>

          <button
            onClick={() => setActiveTab('lessons')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-black transition whitespace-nowrap cursor-pointer ${
              activeTab === 'lessons'
                ? 'duo-btn-brown text-amber-100 shadow-md'
                : 'bg-[#0b2414] text-emerald-300 hover:text-white border-2 border-emerald-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>منهج 28 يوماً ({lessons.filter((l) => l.isCompleted).length}/28)</span>
          </button>

          <button
            onClick={() => setActiveTab('vocab')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-black transition whitespace-nowrap cursor-pointer ${
              activeTab === 'vocab'
                ? 'duo-btn-green text-white shadow-md'
                : 'bg-[#0b2414] text-emerald-300 hover:text-white border-2 border-emerald-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>بنك المفردات ({vocabList.filter((v) => v.isMastered).length}/{vocabList.length})</span>
          </button>
        </div>

        {/* Tab Views */}
        {activeTab === 'path' && (
          <DuolingoPath
            nodes={pathNodes}
            hearts={profile.hearts ?? 5}
            gems={profile.gems ?? 140}
            onUpdateHearts={handleUpdateHearts}
            onAddGems={handleAddGems}
            onAddXp={handleAddXp}
            onNodeComplete={handleNodeComplete}
          />
        )}

        {activeTab === 'motivation' && <MotivationPlayer />}

        {activeTab === 'games' && (
          <SentenceGame 
            onAddXp={handleAddXp} 
            onDeductHeart={() => handleUpdateHearts((h) => Math.max(0, h - 1))}
          />
        )}

        {activeTab === 'lessons' && (
          <LessonList 
            lessons={lessons} 
            onToggleLesson={handleToggleLesson} 
          />
        )}

        {activeTab === 'vocab' && (
          <VocabSection 
            vocabList={vocabList} 
            onToggleMastered={handleToggleMasteredVocab} 
          />
        )}
      </main>

      {/* Persistent Developer Footer */}
      <footer className="bg-[#0b2414] border-t-2 border-emerald-800 py-5 px-4 mt-auto text-xs text-emerald-300/80">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-right">
          <div>
            <p className="font-black text-white text-sm">
              تطبيق MSM ENGLISH • صانع ومطور التطبيق: محمد صالح مهاجر
            </p>
            <p className="text-[11px] text-emerald-400 mt-0.5">
              مبني بنظام الألعاب التحفيزية (Duolingo Style) مع 6 ملفات صوتية تحفيزية وأوفلاين 100%
            </p>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="https://wa.me/23566421752"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 text-emerald-300 hover:text-white bg-emerald-950 px-3 py-1.5 rounded-xl border border-emerald-700 font-mono"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>+23566421752</span>
            </a>

            <button
              onClick={() => setIsAndroidModalOpen(true)}
              className="text-amber-300 hover:text-amber-100 font-bold underline underline-offset-4 cursor-pointer"
            >
              استخراج الـ APK والأندرويد
            </button>
          </div>
        </div>
      </footer>

      {/* Android Architecture & Export Status Modal */}
      <AndroidStatusModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
        onTriggerInstallPWA={install}
        isInstallable={isInstallable}
      />

      {/* Duolingo Hearts & Gems Store Modal */}
      <DuolingoStoreModal
        isOpen={isStoreModalOpen}
        onClose={() => setIsStoreModalOpen(false)}
        hearts={profile.hearts ?? 5}
        gems={profile.gems ?? 140}
        onRefillHearts={handleRefillHearts}
        onSpendGems={handleSpendGems}
      />
    </div>
  );
};

export default App;
