import { MotivationalTrack, Lesson, VocabWord, SentencePuzzle, PathNode, QuizQuestion } from '../types';

export const MOTIVATIONAL_TRACKS: MotivationalTrack[] = [
  {
    id: 'motivation_welcome',
    titleAr: 'الترحيب والانطلاقة نحو الطلاقة',
    titleEn: 'Welcome & Ambition',
    subtitleAr: 'خطوتك الأولى في رحلة تعلم الإنجليزية بثقة وإصرار',
    audioUrl: '/audio/motivation_welcome.mp3',
    durationSec: 12,
    voice: 'Aoede',
    quoteEn: 'Welcome to MSM TN English! Every great journey starts with a single step. Stay committed, practice every day, and unlock your true potential!',
    quoteAr: 'مرحباً بك في MSM TN English! كل رحلة عظيمة تبدأ بخطوة. حافظ على التزامك، وتدرب يومياً، وأطلق العنان لقدراتك الحقيقية!'
  },
  {
    id: 'motivation_mistakes',
    titleAr: 'قوة التعلم من الأخطاء',
    titleEn: 'Power Through Mistakes',
    subtitleAr: 'الأخطاء دليل قاطع على المحاولة والتطور المستمر',
    audioUrl: '/audio/motivation_mistakes.mp3',
    durationSec: 12,
    voice: 'Aoede',
    quoteEn: 'In learning English at MSM TN English, mistakes are your best teachers! Never hesitate to speak. Embrace every attempt and keep moving forward.',
    quoteAr: 'في تعلم الإنجليزية لدى MSM TN English، الأخطاء هي أفضل معلم لك! لا تتردد في التحدث، وتقبّل كل محاولة وواصل التقدم بثقة.'
  },
  {
    id: 'motivation_consistency',
    titleAr: 'سر الاستمرارية اليومية',
    titleEn: 'Daily Consistency',
    subtitleAr: '15 دقيقة يومياً تصنع فارقاً حاسماً في إتقان اللغة',
    audioUrl: '/audio/motivation_consistency.mp3',
    durationSec: 12,
    voice: 'Puck',
    quoteEn: 'Consistency beats talent every single day! Just fifteen minutes a day with MSM TN English will build permanent fluency. You have got the power inside you!',
    quoteAr: 'الاستمرارية تتغلب على الموهبة كل يوم! 15 دقيقة يومياً في MSM TN English ستبني طلاقة مستدامة. القوة بداخلك دائماً!'
  },
  {
    id: 'motivation_energy',
    titleAr: 'شحن الطاقة والتركيز العالي',
    titleEn: 'High Energy & Focus',
    subtitleAr: 'استيقظ بعزيمة ونم برضا وإنجاز حقيقي',
    audioUrl: '/audio/motivation_energy.mp3',
    durationSec: 11,
    voice: 'Fenrir',
    quoteEn: 'Wake up with determination, go to sleep with satisfaction! Your dedication to learning English will open doors worldwide. Keep up the high energy!',
    quoteAr: 'استيقظ بعزيمة ونم برضا وإنجاز! إخلاصك لتعلم الإنجليزية سيفتح لك أبواباً عالمية. حافظ على هذه الطاقة المتوقدة!'
  },
  {
    id: 'motivation_quiz',
    titleAr: 'الثقة قبل الاختبار والتحديات',
    titleEn: 'Quiz & Exam Confidence',
    subtitleAr: 'تنفس بعمق وثق بجهدك وقدرتك على التميز',
    audioUrl: '/audio/motivation_quiz.mp3',
    durationSec: 11,
    voice: 'Charon',
    quoteEn: 'Time for your quiz! Stay calm, trust the effort you have put in, and show what you have learned. You are fully capable of getting a top score!',
    quoteAr: 'حان وقت الاختبار! ابقَ هادئاً، وثق بالجهد الذي بذلته، وأظهر ما تعلمته. أنت قادر تماماً على نيل الدرجة الكاملة!'
  },
  {
    id: 'motivation_streak',
    titleAr: 'الاحتفال بالسلسلة والاستمرارية',
    titleEn: 'Streak Celebration',
    subtitleAr: 'فخر واعتزاز بكل يوم تلتزم فيه بالدراسة',
    audioUrl: '/audio/motivation_streak.mp3',
    durationSec: 12,
    voice: 'Kore',
    quoteEn: 'Outstanding streak! You showed up today for yourself and your dreams. Everyone at MSM TN English is proud of your consistency. Keep shining!',
    quoteAr: 'سلسلة إنجازات استثنائية! لقد حضرت اليوم من أجل نفسك وأحلامك. نفخر جميعاً في MSM TN English بالتزامك المشرف. واصل التألق!'
  }
];

export const INITIAL_LESSONS: Lesson[] = [
  // Week 1
  {
    dayNumber: 1,
    weekNumber: 1,
    titleAr: 'التحيات والتعريف بالنفس',
    titleEn: 'Greetings & Introductions',
    descriptionAr: 'تعلم كيف تقدم نفسك بثقة باللغة الإنجليزية في المواقف الاجتماعية والرسمية.',
    durationMinutes: 20,
    xpReward: 50,
    isCompleted: true,
    grammarRuleAr: 'زمن المضارع البسيط مع الفعل To Be (I am, You are, He/She is).',
    grammarExamples: ['My name is Ahmed and I am excited to learn English.', 'Nice to meet you! Where are you from?']
  },
  {
    dayNumber: 2,
    weekNumber: 1,
    titleAr: 'الروتين اليومي والأوقات',
    titleEn: 'Daily Routine & Time',
    descriptionAr: 'التحدث عن نشاطاتك اليومية وجدولك الزمني بالساعات والأيام.',
    durationMinutes: 25,
    xpReward: 50,
    isCompleted: true,
    grammarRuleAr: 'استخدام أفعال المضارع البسيط مع الضمائر وإضافة s مع المفرد الغائب.',
    grammarExamples: ['I wake up at 7:00 AM every morning.', 'He studies English for thirty minutes every day.']
  },
  {
    dayNumber: 3,
    weekNumber: 1,
    titleAr: 'العائلة والعلاقات الاجتماعية',
    titleEn: 'Family & Relationships',
    descriptionAr: 'وصف أفراد العائلة والأصدقاء واستخدام صفات الملكية بدقة.',
    durationMinutes: 20,
    xpReward: 50,
    isCompleted: true,
    grammarRuleAr: 'صفات الملكية (my, your, his, her, our, their).',
    grammarExamples: ['This is my elder brother, he works as an engineer.', 'Her parents are very supportive of her studies.']
  },
  {
    dayNumber: 4,
    weekNumber: 1,
    titleAr: 'المشاعر والحالات النفسية',
    titleEn: 'Feelings & Emotions',
    descriptionAr: 'التعبير عن المشاعر بدقة وكيف تشعر في أوقات مختلفة من اليوم.',
    durationMinutes: 25,
    xpReward: 50,
    isCompleted: true,
    grammarRuleAr: 'استخدام الصفات بعد أفعال الشعور (feel, look, seem).',
    grammarExamples: ['I feel energized and ready to learn.', 'She looks confident before taking her test.']
  },
  {
    dayNumber: 5,
    weekNumber: 1,
    titleAr: 'السؤال عن الاتجاهات والأماكن',
    titleEn: 'Directions & Places',
    descriptionAr: 'طلب المساعدة في الشارع، ووصف كيفية الوصول إلى الأماكن المختلفة.',
    durationMinutes: 30,
    xpReward: 50,
    isCompleted: false,
    grammarRuleAr: 'حروف الجر المكانية (next to, opposite, between, turn left).',
    grammarExamples: ['Excuse me, how can I get to the central library?', 'Go straight ahead and turn right at the corner.']
  },
  {
    dayNumber: 6,
    weekNumber: 1,
    titleAr: 'التسوق والأسعار',
    titleEn: 'Shopping & Prices',
    descriptionAr: 'طرح الأسئلة في المتجر، الاستفسار عن الأسعار والمقاسات.',
    durationMinutes: 25,
    xpReward: 50,
    isCompleted: false,
    grammarRuleAr: 'الفرق بين How much (لغير المعدود والأسعار) و How many (للمعدود).',
    grammarExamples: ['How much does this jacket cost?', 'How many books would you like to buy?']
  },
  {
    dayNumber: 7,
    weekNumber: 1,
    titleAr: 'مراجعة الأسبوع الأول الشاملة',
    titleEn: 'Week 1 Comprehensive Review',
    descriptionAr: 'تثبيت جميع المفردات والقواعد واختبار التحدث الذاتي.',
    durationMinutes: 35,
    xpReward: 100,
    isCompleted: false,
    grammarRuleAr: 'ملخص شامل لأزمنة المضارع البسيط واستخدام To Be وحروف الجر.',
    grammarExamples: ['Practice makes perfect: build your first complete speech paragraph.']
  },

  // Week 2
  {
    dayNumber: 8,
    weekNumber: 2,
    titleAr: 'الطعام والمطاعم والطلبات',
    titleEn: 'Food & Dining Out',
    descriptionAr: 'طلب الوجبات في المطاعم، التعبير عن الأذواق والتفضيلات الغذائية.',
    durationMinutes: 25,
    xpReward: 60,
    isCompleted: false,
    grammarRuleAr: 'صيغ الطلب المهذب (Would like, Could I have, I will take).',
    grammarExamples: ['I would like a fresh orange juice, please.', 'Could you bring us the menu?']
  },
  {
    dayNumber: 9,
    weekNumber: 2,
    titleAr: 'العمل والمهن والوظائف',
    titleEn: 'Jobs & Professions',
    descriptionAr: 'الحديث عن وظيفتك ومهامك اليومية والمهن المختلفة.',
    durationMinutes: 25,
    xpReward: 60,
    isCompleted: false,
    grammarRuleAr: 'استخدام أدوات التنكير a و an مع المهن والوظائف.',
    grammarExamples: ['She is an architect who designs modern buildings.', 'He works as a software developer.']
  },
  {
    dayNumber: 10,
    weekNumber: 2,
    titleAr: 'المواصلات والسفر والتنقل',
    titleEn: 'Travel & Transportation',
    descriptionAr: 'حجز التذاكر في المطار ومحطة القطار وسؤال السائق.',
    durationMinutes: 30,
    xpReward: 60,
    isCompleted: false,
    grammarRuleAr: 'حروف الجر مع وسائل النقل (by bus, on foot, in the car).',
    grammarExamples: ['I take the metro to university every morning.', 'Our flight departs at 4:30 PM.']
  },
  {
    dayNumber: 11,
    weekNumber: 2,
    titleAr: 'الطقس والمناخ وفصول السنة',
    titleEn: 'Weather & Seasons',
    descriptionAr: 'وصف حالة الطقس اليوم والتنبؤ بالأيام القادمة.',
    durationMinutes: 20,
    xpReward: 60,
    isCompleted: false,
    grammarRuleAr: 'استخدام It is + صفة الطقس (It is sunny, windy, rainy).',
    grammarExamples: ['It looks like it is going to rain this afternoon.', 'Spring is my favorite season of the year.']
  },
  {
    dayNumber: 12,
    weekNumber: 2,
    titleAr: 'الصحة وزيارة الطبيب',
    titleEn: 'Health & Medical Visits',
    descriptionAr: 'وصف الأعراض الشائعة وطلب المساعدة في الصيدلية والعيادة.',
    durationMinutes: 25,
    xpReward: 60,
    isCompleted: false,
    grammarRuleAr: 'استخدام have got مع الأمراض والأعراض (I have a headache).',
    grammarExamples: ['I have had a sore throat since yesterday.', 'Take this medicine twice a day after meals.']
  },
  {
    dayNumber: 13,
    weekNumber: 2,
    titleAr: 'الهوايات والأنشطة الترفيهية',
    titleEn: 'Hobbies & Leisure',
    descriptionAr: 'التحدث عما تحب وتكره القيام به في أوقات فراغك.',
    durationMinutes: 20,
    xpReward: 60,
    isCompleted: false,
    grammarRuleAr: 'الأفعال المتبوعة بـ Gerund مثل like, love, enjoy + ing.',
    grammarExamples: ['I enjoy reading books and playing football on weekends.', 'She loves learning new languages.']
  },
  {
    dayNumber: 14,
    weekNumber: 2,
    titleAr: 'تحدي منتصف المسار الشامل (Unit 2 Boss)',
    titleEn: 'Mid-Program Milestone Boss',
    descriptionAr: 'اختبار نصف البرنامج الشامل لتقييم الطلاقة وربط المحادثات.',
    durationMinutes: 35,
    xpReward: 120,
    isCompleted: false,
    grammarRuleAr: 'المقارنة بين المضارع البسيط والمستمر وصيغ الأسئلة.',
    grammarExamples: ['You have crossed the halfway mark! Keep pushing with determination.']
  },

  // Week 3
  {
    dayNumber: 15,
    weekNumber: 3,
    titleAr: 'الماضي البسيط: سرد الذكريات',
    titleEn: 'Past Simple: Memories & Stories',
    descriptionAr: 'كيف تروي أحداثاً وقعت وانتهت في الماضي بدقة.',
    durationMinutes: 30,
    xpReward: 70,
    isCompleted: false,
    grammarRuleAr: 'تصريف الأفعال المنتظمة بـ ed والأفعال الشاذة الشائعة (went, had, saw).',
    grammarExamples: ['Yesterday I visited my friend in the city.', 'We saw a wonderful exhibition last week.']
  },
  {
    dayNumber: 16,
    weekNumber: 3,
    titleAr: 'المستقبل والخطط القادمة',
    titleEn: 'Future Plans & Intentions',
    descriptionAr: 'الحديث عن طموحاتك ومشاريعك للأسبوع والشهر القادم.',
    durationMinutes: 25,
    xpReward: 70,
    isCompleted: false,
    grammarRuleAr: 'الفرق بين Will (قرارات فورية) و Going to (خطط ونوايا مسبقة).',
    grammarExamples: ['I am going to start a new course next Monday.', 'I think I will travel abroad next year.']
  },
  {
    dayNumber: 17,
    weekNumber: 3,
    titleAr: 'المقارنة والتفضيل بين الأشياء',
    titleEn: 'Comparisons & Superlatives',
    descriptionAr: 'المقارنة بين المنتجات والمدن والخيارات الحياتية.',
    durationMinutes: 25,
    xpReward: 70,
    isCompleted: false,
    grammarRuleAr: 'الصفات القصيرة (er/est) والصفات الطويلة (more/most).',
    grammarExamples: ['English is easier to practice when you speak daily.', 'This is the most interesting book I have read.']
  },
  {
    dayNumber: 18,
    weekNumber: 3,
    titleAr: 'المكالمات الهاتفية والرسائل الرسمية',
    titleEn: 'Phone Calls & Professional Messages',
    descriptionAr: 'إجراء مكالمة هاتفية، ترك رسالة صوتية، وكتابة إيميل قصير.',
    durationMinutes: 30,
    xpReward: 70,
    isCompleted: false,
    grammarRuleAr: 'عبارات الهاتف المعتمدة (May I speak to..., Hold on please).',
    grammarExamples: ['Hello, this is Mohammed calling regarding our appointment.', 'Could you please send me the details via email?']
  },
  {
    dayNumber: 19,
    weekNumber: 3,
    titleAr: 'إبداء الرأي والاتفاق والاختلاف',
    titleEn: 'Opinions & Debates',
    descriptionAr: 'المشاركة في نقاشات هادفة والتعبير عن وجهة نظرك بلباقة.',
    durationMinutes: 25,
    xpReward: 70,
    isCompleted: false,
    grammarRuleAr: 'عبارات الرأي (In my opinion, I believe, I agree/disagree).',
    grammarExamples: ['In my opinion, practice is more valuable than theory alone.', 'I see your point, but let us look at it another way.']
  },
  {
    dayNumber: 20,
    weekNumber: 3,
    titleAr: 'وصف المنزل والأثاث والغرف',
    titleEn: 'House & Home Living',
    descriptionAr: 'وصف منزلك وغرفتك وتأثيث مساحتك المعيشية.',
    durationMinutes: 20,
    xpReward: 70,
    isCompleted: false,
    grammarRuleAr: 'استخدام There is للمفرد و There are للجمع.',
    grammarExamples: ['There is a spacious living room on the ground floor.', 'There are three windows that let in natural light.']
  },
  {
    dayNumber: 21,
    weekNumber: 3,
    titleAr: 'تحدي الأسبوع الثالث (Unit 3 Master)',
    titleEn: 'Week 3 Mastery Challenge',
    descriptionAr: 'تجميع الأزمنة الثلاثة (ماضي ومضارع ومستقبل) في حديث متصل.',
    durationMinutes: 35,
    xpReward: 120,
    isCompleted: false,
    grammarRuleAr: 'الربط الزمني باستخدام أدوات الربط (Because, Although, However, When).',
    grammarExamples: ['Combine your thoughts fluently into rich storytelling.']
  },

  // Week 4
  {
    dayNumber: 22,
    weekNumber: 4,
    titleAr: 'المحادثة السريعة في المطار والفندق',
    titleEn: 'Airport & Hotel Check-in',
    descriptionAr: 'إنهاء إجراءات السفر واستلام الغرفة وحل أي مشكلة فوراً.',
    durationMinutes: 25,
    xpReward: 80,
    isCompleted: false,
    grammarRuleAr: 'استخدام الأفعال المساعدة الشرطية (Can, May, Would).',
    grammarExamples: ['I have a reservation under the name Mohammed Saleh.', 'Is breakfast included in the room price?']
  },
  {
    dayNumber: 23,
    weekNumber: 4,
    titleAr: 'مقابلات العمل وأسئلة السيرة الذاتية',
    titleEn: 'Job Interviews & Resume Talk',
    descriptionAr: 'الإجابة عن نقاط القوة، الخبرات السابقة، وأهدافك المهنية.',
    durationMinutes: 30,
    xpReward: 80,
    isCompleted: false,
    grammarRuleAr: 'استخدام المضارع التام (Present Perfect) للحديث عن الخبرات الحياتية.',
    grammarExamples: ['I have worked in communications for three years.', 'My greatest strength is my ability to solve problems quickly.']
  },
  {
    dayNumber: 24,
    weekNumber: 4,
    titleAr: 'التفاوض وإقناع الآخرين',
    titleEn: 'Negotiation & Persuasion',
    descriptionAr: 'الوصول إلى اتفاقات مرضية وعرض الحلول المقنعة.',
    durationMinutes: 25,
    xpReward: 80,
    isCompleted: false,
    grammarRuleAr: 'الجمل الشرطية من النوع الأول (First Conditional: If + Present, Will + Verb).',
    grammarExamples: ['If we cooperate together, we will achieve outstanding results.', 'What if we try this alternative approach?']
  },
  {
    dayNumber: 25,
    weekNumber: 4,
    titleAr: 'التعامل مع الطوارئ وطلب النجدة',
    titleEn: 'Emergencies & Seeking Help',
    descriptionAr: 'التواصل الفوري في الحالات الحرجة وطلب المساعدة الطبية أو الأمنية.',
    durationMinutes: 20,
    xpReward: 80,
    isCompleted: false,
    grammarRuleAr: 'صيغ الأمر المباشر للسلامة والأفعال الحركية الضرورية.',
    grammarExamples: ['Please call an ambulance immediately!', 'Where is the nearest police station or hospital?']
  },
  {
    dayNumber: 26,
    weekNumber: 4,
    titleAr: 'المصطلحات الشائعة والأمثال الإنجليزية',
    titleEn: 'Idioms & Native Expressions',
    descriptionAr: 'فهم التعبيرات الاصطلاحية التي يستخدمها المتحدثون الأصليون يومياً.',
    durationMinutes: 25,
    xpReward: 80,
    isCompleted: false,
    grammarRuleAr: 'التعابير غير الحرفية (Break a leg, Piece of cake, Once in a blue moon).',
    grammarExamples: ['Learning with daily consistency is a piece of cake!', 'Never give up when the going gets tough.']
  },
  {
    dayNumber: 27,
    weekNumber: 4,
    titleAr: 'إلقاء العروض التقديمية والحديث أمام الجمهور',
    titleEn: 'Presentations & Public Speaking',
    descriptionAr: 'تنظيم أفكارك في مقدمة وعرض وخاتمة والتحدث بطلاقة وثقة.',
    durationMinutes: 30,
    xpReward: 90,
    isCompleted: false,
    grammarRuleAr: 'علامات الانتقال الخطابي (First of all, In addition, To sum up).',
    grammarExamples: ['Today, I would like to talk about the power of self-learning.', 'In conclusion, knowledge transforms our opportunities.']
  },
  {
    dayNumber: 28,
    weekNumber: 4,
    titleAr: 'الاختبار النهائي والتاج الذهبي (Final Graduation Boss)',
    titleEn: 'Grand Graduation & Fluency Crown',
    descriptionAr: 'المحطة الختامية العظمى! نيل شهادة إتمام برنامج MSM ENGLISH التفاعلي.',
    durationMinutes: 40,
    xpReward: 200,
    isCompleted: false,
    grammarRuleAr: 'التطبيق الشامل لجميع المهارات اللغوية المكتسبة على مدار الـ 28 يوماً.',
    grammarExamples: ['Congratulations! You have completed the entire 4-week journey!']
  }
];

export const LEARNING_PATH_NODES: PathNode[] = [
  // Unit 1: Green
  { id: 'n1', unitNumber: 1, dayNumber: 1, titleAr: 'التحيات والتعارف', titleEn: 'Greetings', type: 'lesson', status: 'completed', stars: 3, colorType: 'green', xpReward: 50 },
  { id: 'n2', unitNumber: 1, dayNumber: 2, titleAr: 'الروتين اليومي', titleEn: 'Daily Routine', type: 'lesson', status: 'completed', stars: 3, colorType: 'green', xpReward: 50 },
  { id: 'n3', unitNumber: 1, dayNumber: 3, titleAr: 'صندوق كنز العائلة', titleEn: 'Family Chest', type: 'chest', status: 'completed', stars: 3, colorType: 'brown', xpReward: 40 },
  { id: 'n4', unitNumber: 1, dayNumber: 4, titleAr: 'تحدي المشاعر', titleEn: 'Emotions Quiz', type: 'quiz', status: 'completed', stars: 2, colorType: 'red', xpReward: 50 },
  { id: 'n5', unitNumber: 1, dayNumber: 5, titleAr: 'الاتجاهات والأماكن', titleEn: 'Directions', type: 'lesson', status: 'active', stars: 0, colorType: 'green', xpReward: 50 },
  { id: 'n6', unitNumber: 1, dayNumber: 6, titleAr: 'صوتيات الحماس 1', titleEn: 'Motivation Boost', type: 'audio', status: 'locked', stars: 0, colorType: 'blue', xpReward: 30 },
  { id: 'n7', unitNumber: 1, dayNumber: 7, titleAr: 'زعيم الوحدة الأولى', titleEn: 'Unit 1 Boss', type: 'boss', status: 'locked', stars: 0, colorType: 'red', xpReward: 100 },

  // Unit 2: Brown & Gold
  { id: 'n8', unitNumber: 2, dayNumber: 8, titleAr: 'الطعام والمطاعم', titleEn: 'Food & Dining', type: 'lesson', status: 'locked', stars: 0, colorType: 'green', xpReward: 60 },
  { id: 'n9', unitNumber: 2, dayNumber: 9, titleAr: 'الوظائف والمهن', titleEn: 'Jobs', type: 'lesson', status: 'locked', stars: 0, colorType: 'brown', xpReward: 60 },
  { id: 'n10', unitNumber: 2, dayNumber: 10, titleAr: 'صندوق المسافر', titleEn: 'Traveler Chest', type: 'chest', status: 'locked', stars: 0, colorType: 'gold', xpReward: 50 },
  { id: 'n11', unitNumber: 2, dayNumber: 14, titleAr: 'تحدي نصف المسار', titleEn: 'Midway Boss', type: 'boss', status: 'locked', stars: 0, colorType: 'red', xpReward: 120 },

  // Unit 3: Red & Crimson
  { id: 'n12', unitNumber: 3, dayNumber: 15, titleAr: 'حكايات الماضي', titleEn: 'Past Stories', type: 'lesson', status: 'locked', stars: 0, colorType: 'green', xpReward: 70 },
  { id: 'n13', unitNumber: 3, dayNumber: 18, titleAr: 'المكالمات الهاتفية', titleEn: 'Calls & Emails', type: 'quiz', status: 'locked', stars: 0, colorType: 'red', xpReward: 70 },
  { id: 'n14', unitNumber: 3, dayNumber: 21, titleAr: 'سيد المحادثة', titleEn: 'Conversation Master', type: 'boss', status: 'locked', stars: 0, colorType: 'gold', xpReward: 120 },

  // Unit 4: Golden Crown
  { id: 'n15', unitNumber: 4, dayNumber: 23, titleAr: 'مقابلة العمل', titleEn: 'Job Interview', type: 'lesson', status: 'locked', stars: 0, colorType: 'brown', xpReward: 80 },
  { id: 'n16', unitNumber: 4, dayNumber: 26, titleAr: 'الأمثال الإنجليزية', titleEn: 'Native Idioms', type: 'quiz', status: 'locked', stars: 0, colorType: 'blue', xpReward: 80 },
  { id: 'n17', unitNumber: 4, dayNumber: 28, titleAr: 'التاج الذهبي للتخرج', titleEn: 'Grand Graduation', type: 'boss', status: 'locked', stars: 0, colorType: 'gold', xpReward: 200 }
];

export const VOCABULARY_LIST: VocabWord[] = [
  {
    id: 'v1',
    word: 'Determination',
    phonetic: '/dɪˌtɜː.mɪˈneɪ.ʃən/',
    partOfSpeech: 'noun',
    definitionEn: 'The ability to continue trying to do something, although it is very difficult.',
    translationAr: 'العزيمة والإصرار',
    exampleEn: 'With strong determination, you will speak English fluently.',
    category: 'Motivation',
    difficulty: 'Intermediate',
    isMastered: true
  },
  {
    id: 'v2',
    word: 'Consistency',
    phonetic: '/kənˈsɪs.tən.si/',
    partOfSpeech: 'noun',
    definitionEn: 'The quality of always behaving or performing in a similar way.',
    translationAr: 'الاستمرارية والانتظام',
    exampleEn: 'Daily consistency is the secret of language learning.',
    category: 'Habits',
    difficulty: 'Intermediate',
    isMastered: true
  },
  {
    id: 'v3',
    word: 'Confidence',
    phonetic: '/ˈkɒn.fɪ.dəns/',
    partOfSpeech: 'noun',
    definitionEn: 'A feeling of having trust in yourself and your abilities.',
    translationAr: 'الثقة بالنفس',
    exampleEn: 'Speaking every day builds natural confidence.',
    category: 'Mindset',
    difficulty: 'Beginner',
    isMastered: false
  },
  {
    id: 'v4',
    word: 'Achievement',
    phonetic: '/əˈtʃiːv.mənt/',
    partOfSpeech: 'noun',
    definitionEn: 'Something very good and difficult that you have succeeded in doing.',
    translationAr: 'الإنجاز والنجاح',
    exampleEn: 'Finishing the 4-week program is a proud achievement.',
    category: 'Goals',
    difficulty: 'Elementary',
    isMastered: false
  },
  {
    id: 'v5',
    word: 'Fluency',
    phonetic: '/ˈfluː.ən.si/',
    partOfSpeech: 'noun',
    definitionEn: 'The ability to speak or write a language easily, well, and smoothly.',
    translationAr: 'الطلاقة اللغوية',
    exampleEn: 'Speaking with native recordings improves your fluency.',
    category: 'Language',
    difficulty: 'Intermediate',
    isMastered: false
  },
  {
    id: 'v6',
    word: 'Opportunity',
    phonetic: '/ˌɒp.əˈtjuː.nə.ti/',
    partOfSpeech: 'noun',
    definitionEn: 'An occasion or situation that makes it possible to do something that you want to do.',
    translationAr: 'الفرصة الذهبية',
    exampleEn: 'Mastering English opens countless career opportunities.',
    category: 'Career',
    difficulty: 'Intermediate',
    isMastered: false
  },
  {
    id: 'v7',
    word: 'Practice',
    phonetic: '/ˈpræk.tɪs/',
    partOfSpeech: 'verb/noun',
    definitionEn: 'Action rather than thought or ideas; doing something repeatedly to improve.',
    translationAr: 'الممارسة والتدريب',
    exampleEn: 'Practice English every day for fifteen minutes.',
    category: 'Habits',
    difficulty: 'Beginner',
    isMastered: true
  },
  {
    id: 'v8',
    word: 'Courage',
    phonetic: '/ˈkʌr.ɪdʒ/',
    partOfSpeech: 'noun',
    definitionEn: 'The ability to control your fear in a dangerous or difficult situation.',
    translationAr: 'الشجاعة والجرأة',
    exampleEn: 'Have the courage to speak English even if you make mistakes.',
    category: 'Mindset',
    difficulty: 'Beginner',
    isMastered: false
  },
  {
    id: 'v9',
    word: 'Journey',
    phonetic: '/ˈdʒɜː.ni/',
    partOfSpeech: 'noun',
    definitionEn: 'The act of travelling from one place to another; a long learning process.',
    translationAr: 'الرحلة والمسيرة',
    exampleEn: 'Your English learning journey starts right here today.',
    category: 'General',
    difficulty: 'Beginner',
    isMastered: false
  }
];

export const SENTENCE_PUZZLES: SentencePuzzle[] = [
  {
    id: 'p1',
    promptAr: 'أنا أتعلم اللغة الإنجليزية كل يوم بثقة وإصرار.',
    wordsScrambled: ['English', 'every', 'I', 'learn', 'confidence', 'with', 'day'],
    correctSentence: 'I learn English every day with confidence',
    xpReward: 25
  },
  {
    id: 'p2',
    promptAr: 'الاستمرارية اليومية تصنع الطلاقة الدائمة.',
    wordsScrambled: ['fluency', 'makes', 'consistency', 'Daily', 'permanent'],
    correctSentence: 'Daily consistency makes permanent fluency',
    xpReward: 25
  },
  {
    id: 'p3',
    promptAr: 'الأخطاء هي أفضل معلم في رحلة التعلم.',
    wordsScrambled: ['teachers', 'Mistakes', 'best', 'are', 'your', 'learning', 'in'],
    correctSentence: 'Mistakes are your best teachers in learning',
    xpReward: 30
  },
  {
    id: 'p4',
    promptAr: 'تطبيق إم إس إم يمنحك القوة للحديث بطلاقة.',
    wordsScrambled: ['gives', 'fluency', 'MSM', 'you', 'app', 'power', 'for'],
    correctSentence: 'MSM app gives you power for fluency',
    xpReward: 30
  },
  {
    id: 'p5',
    promptAr: 'الممارسة المستمرة تتغلب على الموهبة دائماً.',
    wordsScrambled: ['talent', 'beats', 'always', 'practice', 'Continuous'],
    correctSentence: 'Continuous practice always beats talent',
    xpReward: 35
  }
];

export const QUICK_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    type: 'multiple-choice',
    promptAr: 'ما هي الترجمة الصحيحة لعبارة "أنا مستعد للتعلم"؟',
    questionEn: 'Choose the correct sentence:',
    options: ['I am ready to learn', 'I is ready to learn', 'I are learn ready', 'Me ready learn'],
    correctAnswer: 'I am ready to learn',
    explanationAr: 'نستخدم الفعل المساعد (am) مع الضمير (I) مع الصفة (ready).'
  },
  {
    id: 'q2',
    type: 'multiple-choice',
    promptAr: 'كيف تقول بالإنجليزية "كم سعر هذا القميص؟"',
    questionEn: 'How do you ask for the price?',
    options: ['How much is this shirt?', 'How many is this shirt?', 'Where price shirt?', 'How cost shirt is?'],
    correctAnswer: 'How much is this shirt?',
    explanationAr: 'نستخدم دائماً "How much" عند السؤال عن الأسعار والمبالغ المالية.'
  },
  {
    id: 'q3',
    type: 'multiple-choice',
    promptAr: 'ما هو معنى كلمة "Determination"؟',
    questionEn: 'What does "Determination" mean?',
    options: ['العزيمة والإصرار', 'التردد والخوف', 'السرعة الفائقة', 'النسيان المؤقت'],
    correctAnswer: 'العزيمة والإصرار',
    explanationAr: 'كلمة Determination تعني الإصرار القوي والعزيمة لتحقيق الأهداف.'
  },
  {
    id: 'q4',
    type: 'multiple-choice',
    promptAr: 'اختر الجملة الصحيحة لتقديم نفسك:',
    questionEn: 'Select the natural greeting:',
    options: ['Nice to meet you, my name is Saleh', 'Nice meet, me Saleh name', 'Meet you nice is Saleh', 'I meet you nicely Saleh'],
    correctAnswer: 'Nice to meet you, my name is Saleh',
    explanationAr: 'صيغة الترحيب والتعارف المهذبة والشائعة هي: Nice to meet you, my name is...'
  }
];

