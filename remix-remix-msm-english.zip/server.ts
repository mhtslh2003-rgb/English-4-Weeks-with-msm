import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      platform: "MSM TN English Hybrid / Web & Android Engine",
      offlineReady: true,
      hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    });
  });

  // Motivational Audio tracks catalog endpoint
  app.get("/api/motivation/tracks", (_req, res) => {
    res.json({
      tracks: [
        {
          id: "motivation_welcome",
          titleEn: "Welcome & Ambition",
          titleAr: "الترحيب والانطلاقة نحو الطلاقة",
          textEn: "Welcome to MSM TN English! Every great journey starts with a single step. Stay committed, practice every day, and unlock your true potential!",
          textAr: "مرحباً بك في MSM TN English! كل رحلة عظيمة تبدأ بخطوة. حافظ على التزامك، وتدرب يومياً، وأطلق العنان لقدراتك الحقيقية!",
          audioUrl: "/audio/motivation_welcome.mp3",
          durationSec: 12
        },
        {
          id: "motivation_mistakes",
          titleEn: "Power Through Mistakes",
          titleAr: "قوة التعلم من الأخطاء",
          textEn: "In learning English at MSM TN English, mistakes are your best teachers! Never hesitate to speak. Embrace every attempt and keep moving forward.",
          textAr: "في تعلم الإنجليزية لدى MSM TN English، الأخطاء هي أفضل معلم لك! لا تتردد في التحدث، وتقبّل كل محاولة وواصل التقدم بثقة.",
          audioUrl: "/audio/motivation_mistakes.mp3",
          durationSec: 12
        },
        {
          id: "motivation_consistency",
          titleEn: "Daily Consistency",
          titleAr: "سر الاستمرارية اليومية",
          textEn: "Consistency beats talent every single day! Just fifteen minutes a day with MSM TN English will build permanent fluency. You have got the power inside you!",
          textAr: "الاستمرارية تتغلب على الموهبة كل يوم! 15 دقيقة يومياً في MSM TN English ستبني طلاقة مستدامة. القوة بداخلك دائماً!",
          audioUrl: "/audio/motivation_consistency.mp3",
          durationSec: 12
        },
        {
          id: "motivation_energy",
          titleEn: "High Energy & Focus",
          titleAr: "شحن الطاقة والتركيز العالي",
          textEn: "Wake up with determination, go to sleep with satisfaction! Your dedication to learning English will open doors worldwide. Keep up the high energy!",
          textAr: "استيقظ بعزيمة ونم برضا وإنجاز! إخلاصك لتعلم الإنجليزية سيفتح لك أبواباً عالمية. حافظ على هذه الطاقة المتوقدة!",
          audioUrl: "/audio/motivation_energy.mp3",
          durationSec: 11
        },
        {
          id: "motivation_quiz",
          titleEn: "Quiz & Exam Confidence",
          titleAr: "الثقة قبل الاختبار والتحديات",
          textEn: "Time for your quiz! Stay calm, trust the effort you have put in, and show what you have learned. You are fully capable of getting a top score!",
          textAr: "حان وقت الاختبار! ابقَ هادئاً، وثق بالجهد الذي بذلته، وأظهر ما تعلمته. أنت قادر تماماً على نيل الدرجة الكاملة!",
          audioUrl: "/audio/motivation_quiz.mp3",
          durationSec: 11
        },
        {
          id: "motivation_streak",
          titleEn: "Streak & Commitment Celebration",
          titleAr: "الاحتفال بالسلسلة والاستمرارية",
          textEn: "Outstanding streak! You showed up today for yourself and your dreams. Everyone at MSM TN English is proud of your consistency. Keep shining!",
          textAr: "سلسلة إنجازات استثنائية! لقد حضرت اليوم من أجل نفسك وأحلامك. نفخر جميعاً في MSM TN English بالتزامك المشرف. واصل التألق!",
          audioUrl: "/audio/motivation_streak.mp3",
          durationSec: 12
        }
      ]
    });
  });

  // AI Writing Correction endpoint
  app.post("/api/gemini/correct", async (req, res) => {
    try {
      const { text } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "النص المطلوب تصحيحه غير موجود" });
      }

      const ai = getAi();
      if (!ai) {
        return res.status(503).json({
          offline: true,
          error: "خدمة الذكاء الاصطناعي تتطلب اتصالاً بالإنترنت ومفتاح API صالح",
        });
      }

      const prompt = `You are a supportive English teacher in an educational app called "MSM TN English".
The student has submitted this English text:
"${text}"

Provide a structured evaluation in JSON format:
{
  "correctedText": "The refined and natural English version",
  "score": number from 1 to 100,
  "corrections": [
    {
      "original": "error part",
      "replacement": "corrected part",
      "explanationAr": "شرح الخطأ والقاعدة باللغة العربية بأسلوب مبسط"
    }
  ],
  "encouragementAr": "كلمة تشجيعية وتحفيزية باللغة العربية للطلاب في أكاديمية MSM TN English",
  "tipsAr": ["نصيحة 1 لتحسين الكتابة", "نصيحة 2"]
}
Return valid JSON only.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      });

      const responseText = response.text || "{}";
      const parsed = JSON.parse(responseText);
      return res.json(parsed);
    } catch (err: any) {
      console.error("AI correction error:", err);
      return res.status(503).json({
        offline: true,
        error: "تعذر الاتصال بخدمة الذكاء الاصطناعي. يرجى التحقق من اتصال الإنترنت.",
      });
    }
  });

  // AI Teacher Conversation Chat endpoint
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      if (!message) {
        return res.status(400).json({ error: "الرسالة مطلوبة" });
      }

      const ai = getAi();
      if (!ai) {
        return res.status(503).json({
          offline: true,
          error: "خدمة المعلم الذكي تتطلب اتصالاً بالإنترنت",
        });
      }

      const systemInstruction = `You are "Coach Sarah", a friendly, patient, native English speaking tutor for Arabic-speaking learners in the "MSM TN English" program.
- Speak primarily in natural, clear, level-appropriate English (A2-B1 level).
- Always include a brief Arabic supportive note or vocabulary hint when introducing a difficult idiom or word.
- Ask questions that prompt the student to practice speaking or writing.
- Keep responses concise (under 80 words) and interactive.
- Correct minor mistakes gently inline without discouraging the learner.`;

      const contents = [];
      if (Array.isArray(history)) {
        for (const item of history) {
          contents.push({
            role: item.role === "assistant" ? "model" : "user",
            parts: [{ text: item.content }],
          });
        }
      }
      contents.push({
        role: "user",
        parts: [{ text: message }],
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      return res.json({
        reply: response.text || "Hello! Keep practicing your English every day!",
      });
    } catch (err: any) {
      console.error("AI Chat error:", err);
      return res.status(503).json({
        offline: true,
        error: "ميزة محادثة المعلم الذكي تتطلب اتصالاً بالإنترنت.",
      });
    }
  });

  // AI Grammar / Vocabulary Explanation endpoint
  app.post("/api/gemini/explain", async (req, res) => {
    try {
      const { topic } = req.body;
      const ai = getAi();
      if (!ai) {
        return res.status(503).json({
          offline: true,
          error: "تتطلب هذه الميزة اتصالاً بالإنترنت",
        });
      }

      const prompt = `Explain this English grammar/vocabulary topic in simple, friendly Arabic with 3 English examples: "${topic}".
Include:
1. القاعدة أو المفهوم بشكل مبسط
2. أمثلة إنجليزية مع ترجمتها
3. أخطاء شائعة يجب تجنبها`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
      });

      return res.json({
        explanation: response.text,
      });
    } catch (err: any) {
      console.error("AI Explain error:", err);
      return res.status(503).json({
        offline: true,
        error: "تتطلب ميزة الشروحات الذكية اتصالاً بالإنترنت.",
      });
    }
  });

  // Vite development middleware vs production static serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[MSM TN English] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
