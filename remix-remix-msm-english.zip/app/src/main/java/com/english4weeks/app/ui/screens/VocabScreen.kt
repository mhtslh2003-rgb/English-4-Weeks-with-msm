package com.english4weeks.app.ui.screens

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.english4weeks.app.data.model.VocabWord
import com.english4weeks.app.ui.viewmodel.MainViewModel
import java.util.Locale

@Composable
fun VocabScreen(
    viewModel: MainViewModel
) {
    val vocabList by viewModel.vocabList.collectAsState()
    val context = LocalContext.current

    // Offline Text-To-Speech for native Android pronunciation
    var tts: TextToSpeech? = null
    tts = TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "مفردات الأسبوع الأول (Week 1 Core Vocabulary)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "مفردات إنجليزية نقية بنظام LTR ونطق أوفلاين محلي (بدون ترجمة بالبطاقة)",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(vocabList) { word ->
            VocabCardCompose(
                vocab = word,
                onSpeak = {
                    tts?.speak(word.word, TextToSpeech.QUEUE_FLUSH, null, null)
                },
                onToggleMaster = {
                    viewModel.updateVocabSRS(word.id, if (word.isMastered) 2 else 5)
                }
            )
        }
    }
}

@Composable
fun VocabCardCompose(
    vocab: VocabWord,
    onSpeak: () -> Unit,
    onToggleMaster: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header with Word, Phonetic and Pronounce button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = vocab.word,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = vocab.phonetic,
                            fontSize = 13.sp,
                            color = Color(0xFF38BDF8),
                            fontStyle = FontStyle.Italic
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "• ${vocab.partOfSpeech}",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onSpeak,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF6366F1).copy(alpha = 0.2f))
                    ) {
                        Icon(
                            Icons.Default.VolumeUp,
                            contentDescription = "Pronounce Word",
                            tint = Color(0xFF818CF8)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = onToggleMaster,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                if (vocab.isMastered) Color(0xFF10B981).copy(alpha = 0.2f)
                                else Color(0xFF334155)
                            )
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Mastered",
                            tint = if (vocab.isMastered) Color(0xFF10B981) else Color(0xFF64748B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // English definition (LTR strictly)
            Text(
                text = vocab.definitionEn,
                fontSize = 14.sp,
                color = Color(0xFFCBD5E1),
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // English example sentence
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F172A))
                    .padding(10.dp)
            ) {
                Text(
                    text = "“${vocab.exampleEn}”",
                    fontSize = 13.sp,
                    color = Color(0xFF93C5FD),
                    fontStyle = FontStyle.Italic
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category and Difficulty tags
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "# ${vocab.category}",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )

                Text(
                    text = vocab.difficulty,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (vocab.difficulty) {
                        "Beginner" -> Color(0xFF34D399)
                        "Elementary" -> Color(0xFF38BDF8)
                        else -> Color(0xFFF59E0B)
                    }
                )
            }
        }
    }
}
