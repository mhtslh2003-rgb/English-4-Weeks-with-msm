package com.english4weeks.app.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF6366F1)
val IndigoDark = Color(0xFF4338CA)
val CyanSecondary = Color(0xFF06B6D4)
val EmeraldAccent = Color(0xFF10B981)
val AmberStar = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF161F30)
val DarkSurfaceVariant = Color(0xFF1E293B)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
