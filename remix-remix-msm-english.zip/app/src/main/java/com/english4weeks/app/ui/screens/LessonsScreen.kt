package com.english4weeks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.english4weeks.app.data.model.Lesson
import com.english4weeks.app.ui.viewmodel.MainViewModel

@Composable
fun LessonsScreen(
    viewModel: MainViewModel
) {
    val lessons by viewModel.lessons.collectAsState()
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }

    if (selectedLesson != null) {
        LessonDetailView(
            lesson = selectedLesson!!,
            onBack = { selectedLesson = null },
            onComplete = {
                viewModel.completeLesson(selectedLesson!!.dayNumber)
                selectedLesson = selectedLesson!!.copy(isCompleted = true)
            }
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B0F19))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "خطة الـ 28 يوماً الدراسية",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "جميع الدروس مخزنة ومتاحة أوفلاين بالكامل بدون إنترنت",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(4.dp))
            }

            items(lessons) { lesson ->
                LessonCard(
                    lesson = lesson,
                    onClick = { selectedLesson = lesson }
                )
            }
        }
    }
}

@Composable
fun LessonCard(
    lesson: Lesson,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (lesson.isCompleted) Color(0xFF132238) else Color(0xFF161F30)
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Day badge
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        if (lesson.isCompleted) Color(0xFF10B981).copy(alpha = 0.2f)
                        else Color(0xFF6366F1).copy(alpha = 0.2f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (lesson.isCompleted) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF10B981))
                } else {
                    Text(
                        text = "${lesson.dayNumber}",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF818CF8),
                        fontSize = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "الأسبوع ${lesson.weekNumber} • اليوم ${lesson.dayNumber}",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.SemiBold
                    )
                    if (lesson.isReviewDay) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "مراجعة شاملة",
                            fontSize = 10.sp,
                            color = Color(0xFFF59E0B),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = lesson.titleAr,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = lesson.titleEn,
                    fontSize = 12.sp,
                    color = Color(0xFF38BDF8)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (lesson.isCompleted) Color(0xFF10B981) else Color(0xFF6366F1)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = if (lesson.isCompleted) "مكتمل ✓" else "دخول",
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun LessonDetailView(
    lesson: Lesson,
    onBack: () -> Unit,
    onComplete: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("← رجوع للدروس", color = Color.White, fontSize = 12.sp)
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF10B981).copy(alpha = 0.2f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("أوفلاين بالكامل", color = Color(0xFF34D399), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "اليوم ${lesson.dayNumber}: ${lesson.titleAr}",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = lesson.titleEn,
            fontSize = 14.sp,
            color = Color(0xFF38BDF8),
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("أهداف الدرس والمحتوى:", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(lesson.descriptionAr, color = Color(0xFFCBD5E1), fontSize = 13.sp, lineHeight = 20.sp)

                Spacer(modifier = Modifier.height(14.dp))
                Text("النقاط الأساسية:", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                lesson.keyTopics.forEach { topic ->
                    Text("• $topic", color = Color(0xFF93C5FD), fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = onComplete,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (lesson.isCompleted) Color(0xFF10B981) else Color(0xFF6366F1)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = if (lesson.isCompleted) "الدرس مكتمل بنجاح (+50 XP)" else "تأكيد إكمال الدرس والحصول على +50 XP",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
