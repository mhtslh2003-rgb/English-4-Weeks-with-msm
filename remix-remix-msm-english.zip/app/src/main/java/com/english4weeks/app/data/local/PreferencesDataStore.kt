package com.english4weeks.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.english4weeks.app.data.model.AudioSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

class PreferencesDataStore(private val context: Context) {

    private object Keys {
        val PRONUNCIATION_ENABLED = booleanPreferencesKey("english_pronunciation_enabled")
        val TEACHER_VOICE_ENABLED = booleanPreferencesKey("teacher_voice_enabled")
        val VOCAL_MOTIVATION_ENABLED = booleanPreferencesKey("vocal_motivation_enabled")
        val IS_MUTED = booleanPreferencesKey("is_muted")
        val REMINDER_HOUR = intPreferencesKey("reminder_hour")
        val REMINDER_MINUTE = intPreferencesKey("reminder_minute")
    }

    val audioSettingsFlow: Flow<AudioSettings> = context.dataStore.data.map { preferences ->
        AudioSettings(
            englishPronunciationEnabled = preferences[Keys.PRONUNCIATION_ENABLED] ?: true,
            teacherVoiceEnabled = preferences[Keys.TEACHER_VOICE_ENABLED] ?: true,
            vocalMotivationEnabled = preferences[Keys.VOCAL_MOTIVATION_ENABLED] ?: true,
            isMuted = preferences[Keys.IS_MUTED] ?: false,
            reminderHour = preferences[Keys.REMINDER_HOUR] ?: 20,
            reminderMinute = preferences[Keys.REMINDER_MINUTE] ?: 0
        )
    }

    suspend fun updatePronunciation(enabled: Boolean) {
        context.dataStore.edit { it[Keys.PRONUNCIATION_ENABLED] = enabled }
    }

    suspend fun updateTeacherVoice(enabled: Boolean) {
        context.dataStore.edit { it[Keys.TEACHER_VOICE_ENABLED] = enabled }
    }

    suspend fun updateVocalMotivation(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VOCAL_MOTIVATION_ENABLED] = enabled }
    }

    suspend fun updateMuted(muted: Boolean) {
        context.dataStore.edit { it[Keys.IS_MUTED] = muted }
    }

    suspend fun updateReminderTime(hour: Int, minute: Int) {
        context.dataStore.edit {
            it[Keys.REMINDER_HOUR] = hour
            it[Keys.REMINDER_MINUTE] = minute
        }
    }
}
