package com.english4weeks.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.english4weeks.app.data.local.entities.LessonProgressEntity
import com.english4weeks.app.data.local.entities.QuizHistoryEntity
import com.english4weeks.app.data.local.entities.UserProfileEntity
import com.english4weeks.app.data.local.entities.VocabItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: UserProfileEntity)

    @Query("UPDATE user_profile SET totalXp = totalXp + :xp, totalStars = totalStars + :stars WHERE id = 1")
    suspend fun addRewards(xp: Int, stars: Int)
}

@Dao
interface LessonProgressDao {
    @Query("SELECT * FROM lesson_progress")
    fun getAllProgress(): Flow<List<LessonProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: LessonProgressEntity)

    @Query("SELECT COUNT(*) FROM lesson_progress WHERE isCompleted = 1")
    suspend fun getCompletedCount(): Int
}

@Dao
interface VocabDao {
    @Query("SELECT * FROM vocab_items")
    fun getAllVocab(): Flow<List<VocabItemEntity>>

    @Query("SELECT * FROM vocab_items WHERE isDifficult = 1")
    fun getDifficultWords(): Flow<List<VocabItemEntity>>

    @Query("SELECT * FROM vocab_items WHERE nextReviewTimestamp <= :currentTime")
    fun getWordsDueForReview(currentTime: Long): Flow<List<VocabItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(words: List<VocabItemEntity>)

    @Update
    suspend fun updateWord(word: VocabItemEntity)
}

@Dao
interface QuizHistoryDao {
    @Query("SELECT * FROM quiz_history ORDER BY timestamp DESC")
    fun getRecentQuizzes(): Flow<List<QuizHistoryEntity>>

    @Insert
    suspend fun insertResult(result: QuizHistoryEntity)
}
