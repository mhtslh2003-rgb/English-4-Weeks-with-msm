package com.english4weeks.app

import android.app.Application
import com.english4weeks.app.data.local.AppDatabase
import com.english4weeks.app.data.local.PreferencesDataStore
import com.english4weeks.app.data.repository.AppRepository
import com.english4weeks.app.data.repository.GeminiAiRepository

class English4WeeksApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var preferencesDataStore: PreferencesDataStore
        private set

    lateinit var appRepository: AppRepository
        private set

    lateinit var aiRepository: GeminiAiRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
        preferencesDataStore = PreferencesDataStore(this)
        appRepository = AppRepository(database)
        aiRepository = GeminiAiRepository(this)
    }
}
