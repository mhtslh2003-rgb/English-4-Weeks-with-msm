package com.english4weeks.app.ui.screens

import android.content.Context
import android.media.MediaPlayer
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.english4weeks.app.R
import com.english4weeks.app.data.model.MotivationalAudioTrack
import com.english4weeks.app.ui.viewmodel.MainViewModel
import kotlinx.coroutines.delay

@Composable
fun MotivationScreen(
    viewModel: MainViewModel
) {
    val context = LocalContext.current

    val tracks = remember {
        listOf(
            MotivationalAudioTrack(
                id = "motivation_welcome",
                titleAr = "الترحيب والانطلاقة نحو الطلاقة",
                titleEn = "Welcome & Ambition",
                subtitleAr = "خطوتك الأولى في رحلة تعلم الإنجليزية بثقة وإصرار",
                rawResId = R.raw.motivation_welcome,
                durationSeconds = 12,
                quoteEn = "Welcome to MSM TN English! Every great journey starts with a single step. Stay committed, practice every day, and unlock your true potential!",
                quoteAr = "مرحباً بك في MSM TN English! كل رحلة عظيمة تبدأ بخطوة. حافظ على التزامك، وتدرب يومياً، وأطلق العنان لقدراتك الحقيقية!"
            ),
            MotivationalAudioTrack(
                id = "motivation_mistakes",
                titleAr = "قوة التعلم من الأخطاء",
                titleEn = "Power Through Mistakes",
                subtitleAr = "الأخطاء دليل قاطع على المحاولة والتطور المستمر",
                rawResId = R.raw.motivation_mistakes,
                durationSeconds = 12,
                quoteEn = "In learning English at MSM TN English, mistakes are your best teachers! Never hesitate to speak. Embrace every attempt and keep moving forward.",
                quoteAr = "في تعلم الإنجليزية لدى MSM TN English، الأخطاء هي أفضل معلم لك! لا تتردد في التحدث، وتقبّل كل محاولة وواصل التقدم بثقة."
            ),
            MotivationalAudioTrack(
                id = "motivation_consistency",
                titleAr = "سر الاستمرارية اليومية",
                titleEn = "Daily Consistency",
                subtitleAr = "15 دقيقة يومياً تصنع فارقاً حاسماً في إتقان اللغة",
                rawResId = R.raw.motivation_consistency,
                durationSeconds = 12,
                quoteEn = "Consistency beats talent every single day! Just fifteen minutes a day with MSM TN English will build permanent fluency. You have got the power inside you!",
                quoteAr = "الاستمرارية تتغلب على الموهبة كل يوم! 15 دقيقة يومياً في MSM TN English ستبني طلاقة مستدامة. القوة بداخلك دائماً!"
            ),
            MotivationalAudioTrack(
                id = "motivation_energy",
                titleAr = "شحن الطاقة والتركيز العالي",
                titleEn = "High Energy & Focus",
                subtitleAr = "استيقظ بعزيمة ونم برضا وإنجاز حقيقي",
                rawResId = R.raw.motivation_energy,
                durationSeconds = 11,
                quoteEn = "Wake up with determination, go to sleep with satisfaction! Your dedication to learning English will open doors worldwide. Keep up the high energy!",
                quoteAr = "استيقظ بعزيمة ونم برضا وإنجاز! إخلاصك لتعلم الإنجليزية سيفتح لك أبواباً عالمية. حافظ على هذه الطاقة المتوقدة!"
            ),
            MotivationalAudioTrack(
                id = "motivation_quiz",
                titleAr = "الثقة قبل الاختبار والتحديات",
                titleEn = "Quiz & Exam Confidence",
                subtitleAr = "تنفس بعمق وثق بجهدك وقدرتك على التميز",
                rawResId = R.raw.motivation_quiz,
                durationSeconds = 11,
                quoteEn = "Time for your quiz! Stay calm, trust the effort you have put in, and show what you have learned. You are fully capable of getting a top score!",
                quoteAr = "حان وقت الاختبار! ابقَ هادئاً، وثق بالجهد الذي بذلته، وأظهر ما تعلمته. أنت قادر تماماً على نيل الدرجة الكاملة!"
            ),
            MotivationalAudioTrack(
                id = "motivation_streak",
                titleAr = "الاحتفال بالسلسلة والاستمرارية",
                titleEn = "Streak Celebration",
                subtitleAr = "فخر واعتزاز بكل يوم تلتزم فيه بالدراسة",
                rawResId = R.raw.motivation_streak,
                durationSeconds = 12,
                quoteEn = "Outstanding streak! You showed up today for yourself and your dreams. Everyone at MSM TN English is proud of your consistency. Keep shining!",
                quoteAr = "سلسلة إنجازات استثنائية! لقد حضرت اليوم من أجل نفسك وأحلامك. نفخر جميعاً في MSM TN English بالتزامك المشرف. واصل التألق!"
            )
        )
    }

    var currentTrackIndex by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    fun playTrack(index: Int) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null

            val track = tracks.getOrNull(index) ?: return
            currentTrackIndex = index

            val mp = MediaPlayer.create(context, track.rawResId)
            if (mp != null) {
                mediaPlayer = mp
                mp.setOnCompletionListener {
                    isPlaying = false
                    progress = 0f
                }
                mp.start()
                isPlaying = true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            isPlaying = false
        }
    }

    fun togglePlayPause() {
        val mp = mediaPlayer
        if (mp != null) {
            if (mp.isPlaying) {
                mp.pause()
                isPlaying = false
            } else {
                mp.start()
                isPlaying = true
            }
        } else {
            playTrack(currentTrackIndex)
        }
    }

    // Periodic progress update
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying && mp.duration > 0) {
                    progress = mp.currentPosition.toFloat() / mp.duration.toFloat()
                }
            }
            delay(100)
        }
    }

    // Release player on exit
    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    val activeTrack = tracks.getOrElse(currentTrackIndex) { tracks[0] }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))

            // Header Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF6366F1).copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Headphones,
                                        contentDescription = null,
                                        tint = Color(0xFF818CF8),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "صوتيات تحفيزية للطلاب",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "MSM TN English Motivational Audio",
                                        fontSize = 12.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            // Offline Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color(0xFF10B981).copy(alpha = 0.2f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "● مدمج أوفلاين",
                                    color = Color(0xFF34D399),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "تسجيلات صوتية حصرية مدمجة محلياً بدون إنترنت، تمنحك شحنة إيجابية يومية لتعزيز التزامك بالدراسة وتجاوز الخوف من التحدث.",
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }
        }

        // Active Player Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Audio Wave Graphic
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(
                                if (isPlaying)
                                    Brush.linearGradient(listOf(Color(0xFF6366F1), Color(0xFF06B6D4)))
                                else
                                    Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF1E293B)))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.GraphicEq else Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = activeTrack.titleAr,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "${activeTrack.titleEn} • ${activeTrack.durationSeconds} ثانية",
                        fontSize = 12.sp,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // English Quote
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "\"${activeTrack.quoteEn}\"",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFFF8FAFC),
                                lineHeight = 19.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = activeTrack.quoteAr,
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8),
                                lineHeight = 18.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress bar
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF6366F1),
                        trackColor = Color(0xFF334155)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Player Controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Previous
                        IconButton(
                            onClick = {
                                val prevIndex = if (currentTrackIndex > 0) currentTrackIndex - 1 else tracks.size - 1
                                playTrack(prevIndex)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipPrevious,
                                contentDescription = "السابق",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Play/Pause Main Button
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(Color(0xFF6366F1), Color(0xFF4F46E5))
                                    )
                                )
                                .clickable { togglePlayPause() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل",
                                tint = Color.White,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Next
                        IconButton(
                            onClick = {
                                val nextIndex = if (currentTrackIndex < tracks.size - 1) currentTrackIndex + 1 else 0
                                playTrack(nextIndex)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = "التالي",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }
            }
        }

        // Section Title: All Motivational Tracks
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "قائمة التسجيلات التحفيزية (${tracks.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "بصوت ناطقين أصليين",
                    fontSize = 12.sp,
                    color = Color(0xFF818CF8)
                )
            }
        }

        // List of Tracks
        itemsIndexed(tracks) { index, track ->
            val isCurrent = currentTrackIndex == index

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) Color(0xFF1E293B) else Color(0xFF131B2A)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (isCurrent) {
                            togglePlayPause()
                        } else {
                            playTrack(index)
                        }
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isCurrent && isPlaying) Color(0xFF6366F1)
                                    else Color(0xFF1E293B)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isCurrent && isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isCurrent && isPlaying) Color.White else Color(0xFF94A3B8),
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = track.titleAr,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isCurrent) Color(0xFF38BDF8) else Color.White
                            )
                            Text(
                                text = track.titleEn,
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    // Duration pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F172A))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${track.durationSeconds}s",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
