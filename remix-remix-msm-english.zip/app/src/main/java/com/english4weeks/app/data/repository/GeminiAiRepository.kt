package com.english4weeks.app.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

sealed class AiResult<out T> {
    data class Success<out T>(val data: T) : AiResult<T>()
    data class OfflineError(val messageAr: String) : AiResult<Nothing>()
    data class Failure(val messageAr: String) : AiResult<Nothing>()
}

data class AiCorrectionResult(
    val correctedText: String,
    val score: Int,
    val encouragementAr: String,
    val correctionsCount: Int
)

class GeminiAiRepository(private val context: Context) {

    // Server-side backend URL (or localhost/cloud run container URL).
    // The API key is securely stored server-side and never exposed to the Android client!
    private val backendBaseUrl = "http://10.0.2.2:3000" // Standard Android emulator loopback to host

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun correctWriting(text: String): AiResult<AiCorrectionResult> = withContext(Dispatchers.IO) {
        if (!isNetworkAvailable()) {
            return@withContext AiResult.OfflineError(
                "هذه الميزة تتطلب اتصالاً بالإنترنت لمحادثة وتحليل الذكاء الاصطناعي. باقي ميزات التطبيق أوفلاين بالكامل."
            )
        }

        try {
            val url = URL("$backendBaseUrl/api/gemini/correct")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }

            val body = JSONObject().put("text", text).toString()
            OutputStreamWriter(conn.outputStream).use { it.write(body) }

            if (conn.responseCode == 200) {
                val responseStr = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                val json = JSONObject(responseStr)
                val corrected = json.optString("correctedText", text)
                val score = json.optInt("score", 90)
                val encouragement = json.optString("encouragementAr", "أحسنت! كتابتك واضحة وجيدة جداً.")
                val corrections = json.optJSONArray("corrections")?.length() ?: 0

                AiResult.Success(AiCorrectionResult(corrected, score, encouragement, corrections))
            } else {
                AiResult.Failure("تعذر إتمام التحليل الآن. يمكنك الاستمرار في الدراسة أوفلاين.")
            }
        } catch (e: Exception) {
            AiResult.OfflineError(
                "هذه الميزة تتطلب اتصالاً بالإنترنت لمحادثة معلم الذكاء الاصطناعي. باقي ميزات التطبيق التعليمية تعمل أوفلاين بالكامل."
            )
        }
    }

    suspend fun sendChatMessage(message: String): AiResult<String> = withContext(Dispatchers.IO) {
        if (!isNetworkAvailable()) {
            return@withContext AiResult.OfflineError(
                "ميزة محادثة المعلم الذكي تتطلب اتصالاً بالإنترنت. الدروس والمفردات والألعاب تعمل أوفلاين بدون انقطاع."
            )
        }

        try {
            val url = URL("$backendBaseUrl/api/gemini/chat")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }

            val body = JSONObject().put("message", message).toString()
            OutputStreamWriter(conn.outputStream).use { it.write(body) }

            if (conn.responseCode == 200) {
                val responseStr = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                val json = JSONObject(responseStr)
                val reply = json.optString("reply", "Great question! Keep practicing every day.")
                AiResult.Success(reply)
            } else {
                AiResult.Failure("الخدمة غير متوفرة حالياً، يرجى المحاولة لاحقاً.")
            }
        } catch (e: Exception) {
            AiResult.OfflineError(
                "هذه الميزة تتطلب اتصالاً بالإنترنت لمحادثة معلم الذكاء الاصطناعي."
            )
        }
    }
}
