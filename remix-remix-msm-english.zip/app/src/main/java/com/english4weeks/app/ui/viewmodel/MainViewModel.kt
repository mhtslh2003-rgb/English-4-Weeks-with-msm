package com.english4weeks.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.english4weeks.app.data.local.entities.UserProfileEntity
import com.english4weeks.app.data.model.AudioSettings
import com.english4weeks.app.data.model.Badge
import com.english4weeks.app.data.model.Lesson
import com.english4weeks.app.data.model.SentencePuzzle
import com.english4weeks.app.data.model.VocabWord
import com.english4weeks.app.data.repository.AppRepository
import com.english4weeks.app.data.repository.GeminiAiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppDestination {
    SPLASH, HOME, LESSONS, VOCABULARY, GAMES, REVIEW, AI_TUTOR, CERTIFICATE, SETTINGS, MOTIVATION
}

class MainViewModel(
    private val appRepository: AppRepository,
    private val aiRepository: GeminiAiRepository
) : ViewModel() {

    private val _currentScreen = MutableStateFlow(AppDestination.SPLASH)
    val currentScreen: StateFlow<AppDestination> = _currentScreen.asStateFlow()

    private val _lessons = MutableStateFlow(appRepository.getFull28DayCurriculum())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    private val _vocabList = MutableStateFlow(appRepository.getWeek1Vocabulary())
    val vocabList: StateFlow<List<VocabWord>> = _vocabList.asStateFlow()

    private val _puzzles = MutableStateFlow(appRepository.getSentencePuzzles())
    val puzzles: StateFlow<List<SentencePuzzle>> = _puzzles.asStateFlow()

    private val _badges = MutableStateFlow(appRepository.getBadges())
    val badges: StateFlow<List<Badge>> = _badges.asStateFlow()

    private val _userProfile = MutableStateFlow(
        UserProfileEntity(
            id = 1,
            name = "محمد الصالح",
            selectedField = "المحادثة اليومية وتطوير المهارات",
            englishLevel = "Beginner (A1)",
            totalXp = 450,
            currentStreak = 4,
            totalStars = 14,
            levelNumber = 2,
            startDate = System.currentTimeMillis() - (4 * 24 * 60 * 60 * 1000L),
            reminderHour = 20,
            reminderMinute = 0
        )
    )
    val userProfile: StateFlow<UserProfileEntity> = _userProfile.asStateFlow()

    private val _audioSettings = MutableStateFlow(AudioSettings())
    val audioSettings: StateFlow<AudioSettings> = _audioSettings.asStateFlow()

    fun navigateTo(destination: AppDestination) {
        _currentScreen.value = destination
    }

    fun completeLesson(dayNumber: Int) {
        val updated = _lessons.value.map {
            if (it.dayNumber == dayNumber) it.copy(isCompleted = true) else it
        }
        _lessons.value = updated
        _userProfile.value = _userProfile.value.copy(
            totalXp = _userProfile.value.totalXp + 50,
            totalStars = _userProfile.value.totalStars + 3
        )
    }

    fun updateVocabSRS(wordId: String, quality: Int) {
        val updated = _vocabList.value.map {
            if (it.id == wordId) {
                it.copy(
                    isMastered = quality >= 4,
                    isDifficult = quality <= 2,
                    repetitionIntervalDays = if (quality >= 4) 7 else 3
                )
            } else it
        }
        _vocabList.value = updated
    }

    fun updateSettings(settings: AudioSettings) {
        _audioSettings.value = settings
    }

    fun resetProgram() {
        val reset = _lessons.value.map { it.copy(isCompleted = false) }
        _lessons.value = reset
        _userProfile.value = _userProfile.value.copy(
            totalXp = 0,
            totalStars = 0,
            currentStreak = 1
        )
    }
}
