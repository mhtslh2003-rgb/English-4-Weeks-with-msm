package com.english4weeks.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.english4weeks.app.ui.components.AppBottomNav
import com.english4weeks.app.ui.screens.AiTutorScreen
import com.english4weeks.app.ui.screens.CertificateScreen
import com.english4weeks.app.ui.screens.GamesScreen
import com.english4weeks.app.ui.screens.HomeScreen
import com.english4weeks.app.ui.screens.LessonsScreen
import com.english4weeks.app.ui.screens.MotivationScreen
import com.english4weeks.app.ui.screens.ReviewScreen
import com.english4weeks.app.ui.screens.SettingsScreen
import com.english4weeks.app.ui.screens.SplashScreen
import com.english4weeks.app.ui.screens.VocabScreen
import com.english4weeks.app.ui.theme.English4WeeksTheme
import com.english4weeks.app.ui.viewmodel.AppDestination
import com.english4weeks.app.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as English4WeeksApp
        val viewModel = MainViewModel(app.appRepository, app.aiRepository)

        setContent {
            English4WeeksTheme {
                // Arabic RTL Layout Direction for the entire application UI
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val currentScreen by viewModel.currentScreen.collectAsState()

                    if (currentScreen == AppDestination.SPLASH) {
                        SplashScreen(
                            onSplashFinished = {
                                viewModel.navigateTo(AppDestination.HOME)
                            }
                        )
                    } else {
                        Scaffold(
                            bottomBar = {
                                AppBottomNav(
                                    currentDestination = currentScreen,
                                    onNavigate = { destination ->
                                        viewModel.navigateTo(destination)
                                    }
                                )
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                when (currentScreen) {
                                    AppDestination.HOME -> HomeScreen(viewModel = viewModel)
                                    AppDestination.LESSONS -> LessonsScreen(viewModel = viewModel)
                                    AppDestination.VOCABULARY -> VocabScreen(viewModel = viewModel)
                                    AppDestination.GAMES -> GamesScreen(viewModel = viewModel)
                                    AppDestination.REVIEW -> ReviewScreen(viewModel = viewModel)
                                    AppDestination.AI_TUTOR -> AiTutorScreen()
                                    AppDestination.CERTIFICATE -> CertificateScreen(viewModel = viewModel)
                                    AppDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
                                    AppDestination.MOTIVATION -> MotivationScreen(viewModel = viewModel)
                                    AppDestination.SPLASH -> Unit
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
