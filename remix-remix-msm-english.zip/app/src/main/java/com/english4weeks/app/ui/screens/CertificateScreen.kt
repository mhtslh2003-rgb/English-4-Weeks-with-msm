package com.english4weeks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.english4weeks.app.ui.viewmodel.MainViewModel

@Composable
fun CertificateScreen(
    viewModel: MainViewModel
) {
    val profile by viewModel.userProfile.collectAsState()
    val lessons by viewModel.lessons.collectAsState()
    val completedCount = lessons.count { it.isCompleted }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "شهادة إتمام البرنامج (Certificate of Completion)",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "تُمنح تلقائياً عند استكمال الدروس والاختبارات الـ 28 (أوفلاين بالكامل)",
            fontSize = 12.sp,
            color = Color(0xFF94A3B8)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Official Certificate Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFF38BDF8))), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF59E0B).copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.School, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(30.dp))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "CERTIFICATE OF COMPLETION",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFFBBF24),
                    letterSpacing = 1.sp
                )

                Text(
                    text = "شهادة إتقان اللغة الإنجليزية - 4 أسابيع",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "This is to certify that",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )

                Text(
                    text = profile.name,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "has successfully completed the 28-day intensive curriculum for English fluency, mastering core vocabulary, sentence structure, and practical daily conversation.",
                    fontSize = 12.sp,
                    color = Color(0xFFCBD5E1),
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("النقاط المكتسبة", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("${profile.totalXp} XP", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("النجوم المحققة", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("${profile.totalStars} ★", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("الدروس المكتملة", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("$completedCount / 28", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Certificate ID: ENG4W-2026-OK9274",
                    fontSize = 9.sp,
                    color = Color(0xFF475569)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { /* Native Android save to gallery / PDF */ },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("تصدير وحفظ الشهادة بصيغة عالية الدقة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}
