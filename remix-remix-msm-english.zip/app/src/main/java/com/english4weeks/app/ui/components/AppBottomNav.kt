package com.english4weeks.app.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import com.english4weeks.app.ui.viewmodel.AppDestination

@Composable
fun AppBottomNav(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFF0F172A)
    ) {
        NavigationBarItem(
            selected = currentDestination == AppDestination.HOME,
            onClick = { onNavigate(AppDestination.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = null) },
            label = { Text("الرئيسية", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color(0xFF818CF8),
                indicatorColor = Color(0xFF4F46E5),
                unselectedIconColor = Color(0xFF64748B),
                unselectedTextColor = Color(0xFF64748B)
            )
        )

        NavigationBarItem(
            selected = currentDestination == AppDestination.LESSONS,
            onClick = { onNavigate(AppDestination.LESSONS) },
            icon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
            label = { Text("الدروس", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color(0xFF818CF8),
                indicatorColor = Color(0xFF4F46E5),
                unselectedIconColor = Color(0xFF64748B),
                unselectedTextColor = Color(0xFF64748B)
            )
        )

        NavigationBarItem(
            selected = currentDestination == AppDestination.VOCABULARY,
            onClick = { onNavigate(AppDestination.VOCABULARY) },
            icon = { Icon(Icons.Default.Translate, contentDescription = null) },
            label = { Text("المفردات", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color(0xFF818CF8),
                indicatorColor = Color(0xFF4F46E5),
                unselectedIconColor = Color(0xFF64748B),
                unselectedTextColor = Color(0xFF64748B)
            )
        )

        NavigationBarItem(
            selected = currentDestination == AppDestination.GAMES,
            onClick = { onNavigate(AppDestination.GAMES) },
            icon = { Icon(Icons.Default.Extension, contentDescription = null) },
            label = { Text("الألعاب", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color(0xFF818CF8),
                indicatorColor = Color(0xFF4F46E5),
                unselectedIconColor = Color(0xFF64748B),
                unselectedTextColor = Color(0xFF64748B)
            )
        )

        NavigationBarItem(
            selected = currentDestination == AppDestination.CERTIFICATE,
            onClick = { onNavigate(AppDestination.CERTIFICATE) },
            icon = { Icon(Icons.Default.School, contentDescription = null) },
            label = { Text("الشهادة", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color(0xFF818CF8),
                indicatorColor = Color(0xFF4F46E5),
                unselectedIconColor = Color(0xFF64748B),
                unselectedTextColor = Color(0xFF64748B)
            )
        )

        NavigationBarItem(
            selected = currentDestination == AppDestination.SETTINGS,
            onClick = { onNavigate(AppDestination.SETTINGS) },
            icon = { Icon(Icons.Default.Settings, contentDescription = null) },
            label = { Text("الإعدادات", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color(0xFF818CF8),
                indicatorColor = Color(0xFF4F46E5),
                unselectedIconColor = Color(0xFF64748B),
                unselectedTextColor = Color(0xFF64748B)
            )
        )
    }
}
