package com.english4weeks.app.data.repository

import com.english4weeks.app.data.local.AppDatabase
import com.english4weeks.app.data.local.entities.LessonProgressEntity
import com.english4weeks.app.data.local.entities.QuizHistoryEntity
import com.english4weeks.app.data.local.entities.UserProfileEntity
import com.english4weeks.app.data.local.entities.VocabItemEntity
import com.english4weeks.app.data.model.Badge
import com.english4weeks.app.data.model.Lesson
import com.english4weeks.app.data.model.QuizQuestion
import com.english4weeks.app.data.model.SentencePuzzle
import com.english4weeks.app.data.model.VocabWord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AppRepository(private val database: AppDatabase) {

    val userProfile: Flow<UserProfileEntity?> = database.userProfileDao().getUserProfile()
    val lessonProgress: Flow<List<LessonProgressEntity>> = database.lessonProgressDao().getAllProgress()
    val allVocab: Flow<List<VocabItemEntity>> = database.vocabDao().getAllVocab()
    val difficultVocab: Flow<List<VocabItemEntity>> = database.vocabDao().getDifficultWords()

    suspend fun saveUserProfile(profile: UserProfileEntity) {
        database.userProfileDao().saveProfile(profile)
    }

    suspend fun completeLesson(dayNumber: Int, score: Int, stars: Int, xp: Int) {
        val entity = LessonProgressEntity(
            dayNumber = dayNumber,
            isCompleted = true,
            completionTimestamp = System.currentTimeMillis(),
            scorePercent = score,
            starsEarned = stars
        )
        database.lessonProgressDao().saveProgress(entity)
        database.userProfileDao().addRewards(xp, stars)
    }

    suspend fun recordQuizResult(title: String, score: Int, total: Int, xp: Int) {
        val result = QuizHistoryEntity(
            quizTitle = title,
            score = score,
            totalQuestions = total,
            xpEarned = xp,
            timestamp = System.currentTimeMillis()
        )
        database.quizHistoryDao().insertResult(result)
        database.userProfileDao().addRewards(xp, 1)
    }

    suspend fun updateSpacedRepetition(wordId: String, quality: Int) { // 1 = hard, 3 = good, 5 = easy
        // SuperMemo SM-2 simplified intervals: 1 day, 3 days, 7 days
        val intervalDays = when {
            quality >= 4 -> 7
            quality >= 3 -> 3
            else -> 1
        }
        val isDifficult = quality < 3
        val nextReview = System.currentTimeMillis() + (intervalDays * 24 * 60 * 60 * 1000L)

        // Update in DB
    }

    // Static curriculum data for 28 days (offline-first, zero internet required)
    fun getFull28DayCurriculum(): List<Lesson> {
        return listOf(
            Lesson(1, 1, "الأبجدية الإنجليزية والنطق الصوتي", "The Alphabet & English Phonetics", "إتقان مخارج الحروف الإنجليزية والأصوات الساكنة والمتحركة", 20, 50, keyTopics = listOf("Vowels vs Consonants", "Phonetic Symbols", "Silent Letters")),
            Lesson(2, 1, "التحيات والتعريف بالنفس", "Greetings & Self-Introduction", "كيف تقدم نفسك، عملك، وبلدك بطلاقة وثقة", 25, 50, keyTopics = listOf("Formal vs Informal Greetings", "Introducing Yourself", "Where are you from?")),
            Lesson(3, 1, "الضمائر وفعل الكينونة (To Be)", "Personal Pronouns & Verb To Be", "أساس تكوين الجمل الإنجليزية البسيطة والنفي والاستفهام", 25, 50, keyTopics = listOf("I, You, He, She, It, We, They", "Am, Is, Are", "Questions with To Be")),
            Lesson(4, 1, "الأرقام والأوقات والأيام", "Numbers, Time & Days", "قراءة التواريخ، الساعات، والأيام لتنظيم المواعيد", 25, 50, keyTopics = listOf("Cardinal & Ordinal Numbers", "Telling the Time", "Days of the Week")),
            Lesson(5, 1, "الأشياء اليومية والصفات الأساسية", "Daily Objects & Basic Adjectives", "وصف المحيط المباشر واستخدام أدوات التعريف والتنكير", 30, 50, keyTopics = listOf("A / An / The", "Colours & Sizes", "This / That / These / Those")),
            Lesson(6, 1, "الأفعال الشائعة في الروتين اليومي", "Daily Routine Action Verbs", "أهم 20 فعلاً إنجليزياً تستخدمهم كل صباح ومساء", 30, 50, keyTopics = listOf("Wake up, Go, Have, Work, Read", "Time Expressions", "Simple Sentences")),
            Lesson(7, 1, "مراجعة الأسبوع الأول الشاملة واختبار التثبيت", "Week 1 Comprehensive Review & Checkpoint", "تثبيت مفردات الأسبوع وتطبيق عملي وتحدي قياس المستوى", 35, 100, isReviewDay = true, keyTopics = listOf("Full Vocab Review", "Speaking Drills", "Progress Test")),

            Lesson(8, 2, "المضارع البسيط وتكوين الجمل", "Present Simple Tense", "التعبير عن العادات، الحقائق، والروتين بوضوح", 25, 60),
            Lesson(9, 2, "صيغ النفي وتكوين الأسئلة", "Negation & Question Formation", "استخدام Do و Does لصياغة الأسئلة المباشرة والنفي", 25, 60),
            Lesson(10, 2, "المضارع المستمر والأفعال الحالية", "Present Continuous Tense", "الحديث عما يحدث الآن بالتحديد وتركيب Am/Is/Are + V-ing", 25, 60),
            Lesson(11, 2, "صفات الملكية وضمائر الملكية", "Possessive Adjectives & Pronouns", "التعبير عن التملك: My, Your, His, Her, Theirs", 25, 60),
            Lesson(12, 2, "حروف الجر المكانية والزمانية", "Prepositions of Time & Place", "الاستخدام الدقيق لـ In, On, At دون خلط", 30, 60),
            Lesson(13, 2, "السؤال بكلمات الاستفهام (Wh- Questions)", "Wh- Questions Mastery", "Who, What, Where, When, Why, How وكيف تجيب عليها", 30, 60),
            Lesson(14, 2, "مراجعة قواعد الأسبوع الثاني واختبار المهارات", "Week 2 Grammar Assessment", "اختبار تطبيقي لقياس جودة صياغة الجمل وتصحيح الأخطاء", 35, 120, isReviewDay = true),

            Lesson(15, 3, "المحادثات في المطاعم والمقاهي", "At the Restaurant & Cafe", "طلب الطعام، السؤال عن المكونات، وسداد الفاتورة", 30, 70),
            Lesson(16, 3, "التسوق والسؤال عن الأسعار والمقاسات", "Shopping & Price Inquiries", "المحادثة مع البائعين، الخصومات، والبحث عن المقاس", 30, 70),
            Lesson(17, 3, "المطار والسفر والفنادق", "Airport, Travel & Hotel Check-in", "إجراءات السفر، حجز الفنادق، والتعامل مع الجوازات", 30, 70),
            Lesson(18, 3, "الماضي البسيط والأفعال الشاذة", "Past Simple & Common Irregular Verbs", "كيف تسرد ما قمت به أمس أو في عطلتك السابقة", 30, 70),
            Lesson(19, 3, "الاتجاهات والسؤال عن الأماكن في المدينة", "Asking for & Giving Directions", "Turn left, go straight, next to, opposite", 30, 70),
            Lesson(20, 3, "التعبير عن المستقبل والتخطيط", "Future Intentions (Going to & Will)", "الحديث عن الخطط والأهداف والمواعيد القادمة", 30, 70),
            Lesson(21, 3, "محاكاة محادثات حية واختبار الأسبوع الثالث", "Week 3 Practical Fluency Test", "تطبيق على جميع المواقف الحياتية وتقييم الطلاقة", 35, 140, isReviewDay = true),

            Lesson(22, 4, "المحادثات المهنية ومقابلات العمل", "Professional English & Job Interviews", "كيف تجيب على أسئلة المقابلات باللغة الإنجليزية", 30, 80),
            Lesson(23, 4, "كتابة الرسائل والبريد الإلكتروني الرسمي", "Writing Formal & Informal Emails", "هيكل الإيميل الاحترافي وعبارات البدء والختام", 30, 80),
            Lesson(24, 4, "المكالمات الهاتفية والرسائل الصوتية", "Phone Calls & Voice Messaging", "عبارات بدء الاتصال، ترك الرسائل، وطلب التوضيح", 30, 80),
            Lesson(25, 4, "التعبير عن الرأي والموافقة والاختلاف", "Expressing Opinions & Debates", "In my opinion, I agree, respectfully disagree", 30, 80),
            Lesson(26, 4, "المصطلحات الشائعة والتعبيرات الاصطلاحية", "Common Idioms & Phrasal Verbs", "أشهر 25 تعبيراً يستعملها المتحدث الأصلي", 30, 80),
            Lesson(27, 4, "المراجعة النهائية الشاملة للبرنامج كاملاً", "Grand Curriculum Revision", "مراجعة كافة القواعد والمفردات والمواقف وتثبيت الحصيلة", 40, 150, isReviewDay = true),
            Lesson(28, 4, "الاختبار النهائي وإصدار شهادة التخرج", "Final Assessment & Graduation Certificate", "الاختبار الشامل المعتمد وإصدار الشهادة الرسمية", 45, 200, isReviewDay = true)
        )
    }

    // Week 1 Core Vocabulary list (100% offline, local English definition and example)
    fun getWeek1Vocabulary(): List<VocabWord> {
        return listOf(
            VocabWord("w1", "Achieve", "/əˈtʃiːv/", "verb", "To successfully finish something or get a result by working hard.", "She worked hard to achieve her learning goals.", "Academic", "Beginner"),
            VocabWord("w2", "Bright", "/braɪt/", "adjective", "Full of light, or showing strong intelligence.", "He has a bright smile and a sharp mind.", "General", "Beginner"),
            VocabWord("w3", "Communicate", "/kəˈmjuːnɪkeɪt/", "verb", "To share information with others by speaking, writing, or moving your body.", "We communicate in English every single day.", "Communication", "Elementary"),
            VocabWord("w4", "Determine", "/dɪˈtɜːmɪn/", "verb", "To decide something firmly after considering the facts.", "Your daily practice will determine your fluency.", "Mindset", "Intermediate"),
            VocabWord("w5", "Enthusiastic", "/ɪnˌθjuːziˈæstɪk/", "adjective", "Feeling or showing a lot of excitement and interest.", "The student is enthusiastic about learning new vocabulary.", "Emotions", "Intermediate"),
            VocabWord("w6", "Focus", "/ˈfəʊkəs/", "noun & verb", "The main center of interest or activity.", "Focus on pronunciation during today's lesson.", "Productivity", "Beginner"),
            VocabWord("w7", "Grateful", "/ˈɡreɪtfʊl/", "adjective", "Feeling or showing an appreciation of kindness.", "I am grateful for this wonderful opportunity.", "Social", "Elementary"),
            VocabWord("w8", "Habit", "/ˈhæbɪt/", "noun", "A settled or regular tendency or practice.", "Studying 20 minutes a day is an excellent habit.", "Daily Life", "Beginner"),
            VocabWord("w9", "Improve", "/ɪmˈpruːv/", "verb", "To make or become better.", "Reading daily will improve your English vocabulary.", "Learning", "Beginner"),
            VocabWord("w10", "Journey", "/ˈdʒɜːni/", "noun", "An act of traveling from one place or state to another.", "Learning a language is an exciting lifelong journey.", "General", "Elementary"),
            VocabWord("w11", "Knowledge", "/ˈnɒlɪdʒ/", "noun", "Facts, information, and skills acquired through experience or education.", "Knowledge gives you the confidence to speak.", "Education", "Elementary"),
            VocabWord("w12", "Listen", "/ˈlɪsən/", "verb", "To give one's attention to sound or speech.", "Listen carefully to the teacher's pronunciation.", "Core Skills", "Beginner"),
            VocabWord("w13", "Motivate", "/ˈməʊtɪveɪt/", "verb", "To provide someone with a reason for doing something.", "Progress stars motivate students to continue.", "Mindset", "Elementary"),
            VocabWord("w14", "Notice", "/ˈnəʊtɪs/", "verb", "To become aware of something.", "You will notice big improvements after 4 weeks.", "Daily Life", "Beginner"),
            VocabWord("w15", "Opportunity", "/ˌɒpəˈtjuːnɪti/", "noun", "A set of circumstances that makes it possible to do something.", "Speaking English opens up international opportunities.", "Career", "Intermediate"),
            VocabWord("w16", "Practice", "/ˈpræktɪs/", "noun & verb", "Repeated exercise in an activity or skill.", "Daily practice makes your English fluent.", "Learning", "Beginner"),
            VocabWord("w17", "Quickly", "/ˈkwɪkli/", "adverb", "At a fast speed or in a short time.", "Consistent study helps you learn words quickly.", "General", "Beginner"),
            VocabWord("w18", "Remember", "/rɪˈmɛmbə/", "verb", "To have in or be able to bring to one's mind an awareness of someone or something.", "Use spaced repetition to remember difficult words.", "Memory", "Beginner"),
            VocabWord("w19", "Schedule", "/ˈʃɛdjuːl/", "noun", "A plan for carrying out a process or procedure.", "Stick to your 28-day study schedule.", "Productivity", "Elementary"),
            VocabWord("w20", "Travel", "/ˈtrævəl/", "verb & noun", "To go from one place to another.", "I want to travel the world and speak English.", "Lifestyle", "Beginner"),
            VocabWord("w21", "Understand", "/ˌʌndəˈstænd/", "verb", "To perceive the intended meaning of words or ideas.", "Now I understand English grammar rules easily.", "Core Skills", "Beginner"),
            VocabWord("w22", "Vocabulary", "/vəˈkæbjʊləri/", "noun", "The body of words used in a particular language.", "Expanding your vocabulary is essential for communication.", "Education", "Elementary"),
            VocabWord("w23", "Wisdom", "/ˈwɪzdəm/", "noun", "The quality of having experience, knowledge, and good judgment.", "Wisdom comes from consistent learning and reflection.", "General", "Intermediate"),
            VocabWord("w24", "Yield", "/jiːld/", "verb", "To produce or provide a natural, agricultural, or industrial product.", "Daily discipline will yield outstanding results.", "Academic", "Intermediate")
        )
    }

    fun getSentencePuzzles(): List<SentencePuzzle> {
        return listOf(
            SentencePuzzle("sp1", "رتّب الكلمات لتكوين جملة: أنا أدرس الإنجليزية كل يوم", listOf("English", "study", "every", "I", "day"), "I study English every day"),
            SentencePuzzle("sp2", "رتّب الكلمات: التعلم المستمر يصنع الفرق الحقيقي", listOf("Continuous", "makes", "a", "learning", "real", "difference"), "Continuous learning makes a real difference"),
            SentencePuzzle("sp3", "رتّب الكلمات: أين يقع أقرب فندق من هنا؟", listOf("is", "hotel", "Where", "the", "from", "nearest", "here?"), "Where is the nearest hotel from here?"),
            SentencePuzzle("sp4", "رتّب الكلمات: هل يمكنك مساعدتي في نطق هذه الكلمة؟", listOf("Can", "help", "you", "me", "pronounce", "this", "word?"), "Can you help me pronounce this word?")
        )
    }

    fun getBadges(): List<Badge> {
        return listOf(
            Badge("b1", "الخطوة الأولى", "إكمال أول درس بنجاح في اليوم الأول", "CheckCircle", true, "اليوم الأول"),
            Badge("b2", "شعلة الحماس", "الحفاظ على دراسة 3 أيام متتالية", "Flame", true, "اليوم الثالث"),
            Badge("b3", "ملك المفردات", "إتقان 20 كلمة إنجليزية في الأسبوع الأول", "BookOpen", false),
            Badge("b4", "بطل الأسبوع الأول", "إتمام أول 7 أيام من الجدول الزمني", "Award", false),
            Badge("b5", "عبقري القواعد", "الحصول على 100% في اختبار القواعد", "Zap", false),
            Badge("b6", "تخرج 4 أسابيع", "إكمال البرنامج الدراسي كاملاً واستخراج الشهادة", "GraduationCap", false)
        )
    }
}
