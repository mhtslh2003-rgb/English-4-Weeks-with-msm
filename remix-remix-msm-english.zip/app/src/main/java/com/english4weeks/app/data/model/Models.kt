package com.english4weeks.app.data.model

data class Lesson(
    val dayNumber: Int,
    val weekNumber: Int,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val durationMinutes: Int = 25,
    val xpReward: Int = 50,
    val isCompleted: Boolean = false,
    val isLocked: Boolean = false,
    val isReviewDay: Boolean = false,
    val keyTopics: List<String> = emptyList(),
    val grammarRuleAr: String = "",
    val grammarExamples: List<String> = emptyList()
)

data class VocabWord(
    val id: String,
    val word: String,
    val phonetic: String,
    val partOfSpeech: String, // noun, verb, adjective, etc.
    val definitionEn: String,
    val exampleEn: String,
    val category: String,
    val difficulty: String, // Beginner, Elementary, Intermediate
    val week: Int = 1,
    val isMastered: Boolean = false,
    val isDifficult: Boolean = false,
    val repetitionIntervalDays: Int = 1,
    val nextReviewDate: Long = 0L
)

data class QuizQuestion(
    val id: String,
    val questionEn: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanationAr: String,
    val xpPoints: Int = 15
)

data class SentencePuzzle(
    val id: String,
    val promptAr: String,
    val wordsScrambled: List<String>,
    val correctSentence: String,
    val xpReward: Int = 20
)

data class StudySchedule(
    val startDateTimestamp: Long,
    val endDateTimestamp: Long,
    val dailyStartTime: String = "20:00",
    val dailyDurationMinutes: Int = 30,
    val studyDaysMask: List<Int> = listOf(1, 2, 3, 4, 5, 6, 7), // All week
    val completedDaysCount: Int = 0,
    val missedDaysCount: Int = 0,
    val currentDayIndex: Int = 1
)

data class UserProfile(
    val name: String = "الطالب المجتهد",
    val levelName: String = "Beginner (A1)",
    val selectedField: String = "المحادثة العامة وتطوير المهارات",
    val totalXp: Int = 0,
    val currentStreak: Int = 1,
    val totalStars: Int = 0,
    val levelNumber: Int = 1,
    val completedLessonsCount: Int = 0,
    val masterVocabCount: Int = 0
)

data class Badge(
    val id: String,
    val titleAr: String,
    val descriptionAr: String,
    val iconName: String,
    val isUnlocked: Boolean = false,
    val unlockedAtDate: String = ""
)

data class AudioSettings(
    val englishPronunciationEnabled: Boolean = true,
    val teacherVoiceEnabled: Boolean = true,
    val vocalMotivationEnabled: Boolean = true,
    val isMuted: Boolean = false,
    val reminderHour: Int = 20,
    val reminderMinute: Int = 0
)

data class MotivationalAudioTrack(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val subtitleAr: String,
    val rawResId: Int,
    val durationSeconds: Int,
    val quoteEn: String,
    val quoteAr: String
)

