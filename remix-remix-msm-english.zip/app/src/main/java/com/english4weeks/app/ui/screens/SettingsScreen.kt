package com.english4weeks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.english4weeks.app.ui.viewmodel.MainViewModel

@Composable
fun SettingsScreen(
    viewModel: MainViewModel
) {
    val settings by viewModel.audioSettings.collectAsState()
    var showResetConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "إعدادات التطبيق والصوت (Settings)",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "التحكم في الأصوات التعليمية وحفظ البيانات محلياً (بدون موسيقى خلفية)",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
        }

        // Sound toggles card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "خيارات الصوت التعليمي",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    SettingToggleRow(
                        title = "نطق المفردات الإنجليزية",
                        subtitle = "تشغيل النطق الصوتي التلقائي واليدوي للكلمات",
                        checked = settings.englishPronunciationEnabled,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(englishPronunciationEnabled = it))
                        }
                    )

                    SettingToggleRow(
                        title = "صوت المعلم التوجيهي",
                        subtitle = "قراءة توجيهات الدروس والتعليمات",
                        checked = settings.teacherVoiceEnabled,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(teacherVoiceEnabled = it))
                        }
                    )

                    SettingToggleRow(
                        title = "التحفيز الصوتي عند النجاح",
                        subtitle = "أصوات تشجيعية خفيفة عند حل التمارين الصحيحة",
                        checked = settings.vocalMotivationEnabled,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(vocalMotivationEnabled = it))
                        }
                    )

                    SettingToggleRow(
                        title = "كتم جميع الأصوات",
                        subtitle = "إيقاف المؤثرات الصوتية بالكامل للدراسة الصامتة",
                        checked = settings.isMuted,
                        onCheckedChange = {
                            viewModel.updateSettings(settings.copy(isMuted = it))
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• الموسيقى التصويرية وموسيقى الخلفية معطلة دائماً بتصميم مخصص للتركيز التام.",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }

        // Storage & Program Reset
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("إدارة البيانات والتقدم", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "بياناتك مخزنة محلياً على جهازك بواسطة قاعدة بيانات Room المشفرة، ولن تضيع عند إغلاق التطبيق.",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8),
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    if (!showResetConfirm) {
                        Button(
                            onClick = { showResetConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إعادة ضبط البرنامج الدراسي من الصفر", color = Color(0xFFF87171), fontSize = 12.sp)
                        }
                    } else {
                        Column {
                            Text("هل أنت متأكد؟ سيتم تصفير التقدم الحالي وإعادة البدء من اليوم الأول.", color = Color(0xFFFCA5A5), fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        viewModel.resetProgram()
                                        showResetConfirm = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                                ) {
                                    Text("نعم، إعادة ضبط")
                                }
                                Button(
                                    onClick = { showResetConfirm = false },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                                ) {
                                    Text("إلغاء")
                                }
                            }
                        }
                    }
                }
            }
        }

        // App Information
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("معلومات التطبيق", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("اسم التطبيق: English 4 Weeks", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                    Text("الإصدار: 1.0.0 (Native Android Jetpack Compose)", fontSize = 12.sp, color = Color(0xFF94A3B8))
                    Text("معرف الحزمة: com.english4weeks.app", fontSize = 12.sp, color = Color(0xFF94A3B8))
                    Text("حالة النظام: Offline-First Native Room Architecture", fontSize = 12.sp, color = Color(0xFF34D399))
                }
            }
        }
    }
}

@Composable
fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
            Text(subtitle, fontSize = 11.sp, color = Color(0xFF94A3B8))
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF6366F1),
                uncheckedThumbColor = Color(0xFF94A3B8),
                uncheckedTrackColor = Color(0xFF334155)
            )
        )
    }
}
