package com.english4weeks.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.english4weeks.app.data.local.dao.LessonProgressDao
import com.english4weeks.app.data.local.dao.QuizHistoryDao
import com.english4weeks.app.data.local.dao.UserProfileDao
import com.english4weeks.app.data.local.dao.VocabDao
import com.english4weeks.app.data.local.entities.LessonProgressEntity
import com.english4weeks.app.data.local.entities.QuizHistoryEntity
import com.english4weeks.app.data.local.entities.UserProfileEntity
import com.english4weeks.app.data.local.entities.VocabItemEntity

@Database(
    entities = [
        UserProfileEntity::class,
        LessonProgressEntity::class,
        VocabItemEntity::class,
        QuizHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun lessonProgressDao(): LessonProgressDao
    abstract fun vocabDao(): VocabDao
    abstract fun quizHistoryDao(): QuizHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "english_4_weeks_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
