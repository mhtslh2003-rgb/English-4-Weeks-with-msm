package com.english4weeks.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val selectedField: String,
    val englishLevel: String,
    val totalXp: Int,
    val currentStreak: Int,
    val totalStars: Int,
    val levelNumber: Int,
    val startDate: Long,
    val reminderHour: Int,
    val reminderMinute: Int
)

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val dayNumber: Int,
    val isCompleted: Boolean,
    val completionTimestamp: Long,
    val scorePercent: Int,
    val starsEarned: Int
)

@Entity(tableName = "vocab_items")
data class VocabItemEntity(
    @PrimaryKey val wordId: String,
    val word: String,
    val phonetic: String,
    val partOfSpeech: String,
    val definitionEn: String,
    val exampleEn: String,
    val category: String,
    val difficulty: String,
    val isMastered: Boolean,
    val isDifficult: Boolean,
    val repetitionInterval: Int,
    val nextReviewTimestamp: Long
)

@Entity(tableName = "quiz_history")
data class QuizHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val quizTitle: String,
    val score: Int,
    val totalQuestions: Int,
    val xpEarned: Int,
    val timestamp: Long
)
