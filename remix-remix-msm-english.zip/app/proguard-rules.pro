# Android Proguard Rules for English 4 Weeks
-keep class com.english4weeks.app.data.model.** { *; }
-keep class com.english4weeks.app.data.local.entities.** { *; }
