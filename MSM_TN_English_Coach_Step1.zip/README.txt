MSM TN English Coach — Step 1

This project makes the Telegram bot respond to /start and show the main menu.

Deployment:
1. Upload this ZIP to Vercel Drop.
2. In the Vercel project, open Settings → Environment Variables.
3. Add:
   Name: BOT_TOKEN
   Value: YOUR TELEGRAM BOT TOKEN
   Environment: Production
4. Redeploy.
5. Set the Telegram webhook to:
   https://api.telegram.org/botYOUR_TOKEN/setWebhook?url=YOUR_VERCEL_URL/api/webhook

Important:
- Never share BOT_TOKEN with anyone.
- The webhook URL contains the token, so use it only privately.
- After the webhook is set, send /start to your bot.

The buttons are placeholders for Step 2 onward.
