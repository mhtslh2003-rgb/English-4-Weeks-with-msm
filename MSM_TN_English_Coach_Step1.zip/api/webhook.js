export default async function handler(req, res) {
  if (req.method !== "POST" && req.method !== "GET") {
    return res.status(405).json({ ok: false, error: "Method not allowed" });
  }

  // GET is only a health check.
  if (req.method === "GET") {
    return res.status(200).json({
      ok: true,
      bot: "MSM TN English Coach",
      message: "Webhook is running."
    });
  }

  const token = process.env.BOT_TOKEN;
  if (!token) {
    return res.status(500).json({ ok: false, error: "BOT_TOKEN is not configured" });
  }

  try {
    const update = req.body || {};
    const message = update.message;
    const callback = update.callback_query;

    if (message?.text) {
      const chatId = message.chat.id;
      const text = message.text.trim();

      if (text === "/start" || text.startsWith("/start ")) {
        await telegram(token, "sendMessage", {
          chat_id: chatId,
          text:
            "🇬🇧 Welcome to MSM TN English Coach!\\n\\n" +
            "Your personal English teacher is ready.\\n\\n" +
            "Choose an option below to begin:",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "📚 Learn", callback_data: "learn" },
                { text: "🔄 Review", callback_data: "review" }
              ],
              [
                { text: "🧠 Test Me", callback_data: "test" },
                { text: "🧩 Sentences", callback_data: "sentences" }
              ],
              [
                { text: "✍️ Writing", callback_data: "writing" },
                { text: "📊 My Progress", callback_data: "progress" }
              ],
              [
                { text: "⚙️ Settings", callback_data: "settings" }
              ]
            ]
          }
        });
      } else if (text === "/help") {
        await telegram(token, "sendMessage", {
          chat_id: chatId,
          text:
            "MSM TN English Coach helps you learn English step by step.\\n\\n" +
            "Use /start to open the main menu."
        });
      } else {
        await telegram(token, "sendMessage", {
          chat_id: chatId,
          text:
            "I'm ready to help you learn English. 🇬🇧\\n\\n" +
            "Send /start to open your learning menu."
        });
      }
    }

    if (callback) {
      const chatId = callback.message.chat.id;
      const action = callback.data;

      const messages = {
        learn: "📚 Learn\\n\\nYour daily lesson will appear here soon.",
        review: "🔄 Review\\n\\nYour review system will appear here soon.",
        test: "🧠 Test Me\\n\\nInteractive tests will appear here soon.",
        sentences: "🧩 Sentences\\n\\nSentence-building practice will appear here soon.",
        writing: "✍️ Writing\\n\\nWriting practice and correction will appear here soon.",
        progress: "📊 My Progress\\n\\nYour progress dashboard will appear here soon.",
        settings: "⚙️ Settings\\n\\nYour learning settings will appear here soon."
      };

      await telegram(token, "answerCallbackQuery", {
        callback_query_id: callback.id
      });

      await telegram(token, "sendMessage", {
        chat_id: chatId,
        text: messages[action] || "Choose an option from the menu."
      });
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(200).json({ ok: false });
  }
}

async function telegram(token, method, body) {
  const response = await fetch(
    `https://api.telegram.org/bot${token}/${method}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }
  );

  const data = await response.json();
  if (!data.ok) {
    throw new Error(data.description || "Telegram API error");
  }
  return data;
}
